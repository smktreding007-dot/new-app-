package com.bestwinesport.app

import android.app.DatePickerDialog
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun AddMoneyScreen(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val minDep by rflow(init = "") { Repo.setting("minDeposit") }
    val zapupiEnabled by rflow(init = "") { Repo.setting("zapupiEnabled") }
    val zapupiKeySet by rflow(init = "") { Repo.setting("zapupiKeySet") }
    var amt by remember { mutableStateOf("") }
    var startingZapupi by remember { mutableStateOf(false) }
    var checkingZapupi by remember { mutableStateOf(false) }
    var zapupiOrder by remember { mutableStateOf<ZapupiOrder?>(null) }
    var showCheckout by remember { mutableStateOf(false) }
    val minValue = minDep.toDoubleOrNull() ?: 10.0
    val maxDep by rflow(init = "") { Repo.setting("maxDeposit") }
    val chipsRaw by rflow(init = "") { Repo.setting("depositChips") }
    // Admin switch (Settings -> "Add Coins page: show Select amount quick amount chips"). Off = only the amount field.
    val chipsEnabled by rflow(init = "") { Repo.setting("depositChipsEnabled") }
    val methodName by rflow(init = "") { Repo.setting("depositMethodName") }
    // Admin choice (Settings -> "Add Coins page design"): "old" = previous page, anything else = NEW page (default).
    // The last value is kept on the phone so the page never flips from one design to the other while opening.
    val uiPrefs = remember { ctx.getSharedPreferences("ui_prefs", android.content.Context.MODE_PRIVATE) }
    val styleRaw by rflow(init = uiPrefs.getString("addMoneyStyle", "") ?: "") { Repo.setting("addMoneyStyle") }
    LaunchedEffect(styleRaw) { uiPrefs.edit().putString("addMoneyStyle", styleRaw).apply() }
    val oldStyle = styleRaw.trim().equals("old", ignoreCase = true)
    val chips = remember(chipsRaw) { chipsRaw.split(",").map { it.trim() }.filter { it.toDoubleOrNull() != null }.ifEmpty { listOf("10", "20", "50", "100", "200", "500", "1000") } }
    val maxValue = maxDep.toDoubleOrNull() ?: 50000.0
    val amount = amt.toDoubleOrNull() ?: 0.0
    val validAmount = amount >= minValue && amount <= maxValue
    // ZapUPI is used only when the admin saved the key AND enabled it; otherwise the manual UPI (ID + QR + UTR) flow is used.
    val online = zapupiEnabled.trim().equals("true", ignoreCase = true) && zapupiKeySet.trim().equals("true", ignoreCase = true)
    /** Shows the final result once. [order] is cleared at the end, so no extra payment card is ever left on the screen. */
    fun showResult(status: String) {
        when (status) {
            "success" -> { ctx.toast(zapupiText("success")); nav.popBackStack() }
            "failed", "test" -> ctx.toast(zapupiText("failed"))
            "amount_mismatch" -> ctx.toast(zapupiText("review"))
            else -> ctx.toast(zapupiText("late"))
        }
    }
    /** The player left the payment page: check the payment quietly for a short time. Paid -> coins added; not paid -> only a short message. */
    fun finishPayment(order: ZapupiOrder) {
        if (checkingZapupi) return
        scope.launch {
            checkingZapupi = true
            var result = "pending"
            try {
                for (i in 0 until 8) {
                    val st = try { ZapupiPaymentApi.checkStatus(order.orderId) } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (_: Exception) { "pending" }
                    if (st == "success" || st == "failed" || st == "test" || st == "amount_mismatch") { result = st; break }
                    if (i < 7) kotlinx.coroutines.delay(3000)
                }
                zapupiOrder = null
                showResult(result)
            } finally { checkingZapupi = false; zapupiOrder = null }
        }
    }
    // While the payment page is open, the payment status is checked every few seconds; the page closes by itself when the payment is done.
    LaunchedEffect(showCheckout, zapupiOrder) {
        val order = zapupiOrder
        if (!showCheckout || order == null) return@LaunchedEffect
        while (true) {
            kotlinx.coroutines.delay(4000)
            val st = try { ZapupiPaymentApi.checkStatus(order.orderId) } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (_: Exception) { "pending" }
            if (st == "success" || st == "failed" || st == "test" || st == "amount_mismatch") {
                showCheckout = false; zapupiOrder = null
                ZapupiCheckoutActivity.closeOpen()
                showResult(st)
                return@LaunchedEffect
            }
        }
    }
    fun startZapupiPayment(amount: Double) {
        if (startingZapupi) return
        if (amount < minValue) { ctx.toast("Minimum amount ₹${money(minValue)}"); return }
        if (amount > maxValue) { ctx.toast("${tx("Maximum amount")} ₹${money(maxValue)}"); return }
        scope.launch {
            startingZapupi = true
            try {
                val created = ZapupiPaymentApi.createOrder(amount)
                zapupiOrder = created
                ctx.toast(zapupiText("created"))
                showCheckout = true
            } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) { ctx.toast(e.message ?: zapupiText("start_error")) }
            finally { startingZapupi = false }
        }
    }
    if (oldStyle) {
        // ---- OLD design (previous Add Money page) ----
        Column(Modifier.fillMaxSize()) {
            BackBar(tx("Add Money"), nav)
            Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState())) {
                Text(tx("Select amount"), fontSize = 18.sp, modifier = Modifier.padding(bottom = 12.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    chips.forEach { c ->
                        val on = amt == c
                        Box(Modifier.clip(RoundedCornerShape(8.dp)).background(if (on) ButtonC else Color.Transparent).border(1.dp, Color.White, RoundedCornerShape(8.dp))
                            .clickable { amt = c }.padding(horizontal = 16.dp, vertical = 14.dp), contentAlignment = Alignment.Center) {
                            Text(c, fontSize = 15.sp, color = if (on) Orange else Color.White)
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(vertical = 22.dp), verticalAlignment = Alignment.CenterVertically) {
                    HorizontalDivider(Modifier.weight(1f), color = Color.Gray); Text("   ${tx("OR")}   ", fontSize = 15.sp); HorizontalDivider(Modifier.weight(1f), color = Color.Gray)
                }
                OutlinedTextField(amt, { amt = it.filter { ch -> ch.isDigit() || ch == '.' } }, Modifier.fillMaxWidth(), placeholder = { Text(tx("amount"), color = Color.Gray) },
                    shape = RoundedCornerShape(8.dp), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Color.White, unfocusedBorderColor = Color.White))
                Row(Modifier.padding(vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(true, {}, colors = RadioButtonDefaults.colors(selectedColor = Orange))
                    Text(if (online) methodName.ifBlank { "ZapUPI" } else tx("UPI (Manual)"), fontSize = 13.sp)
                }
                if (amount > 0 && validAmount) Text("${tx("You will pay")} ₹${money(amount)}", Modifier.fillMaxWidth().padding(bottom = 10.dp), color = Orange, textAlign = TextAlign.Center, fontSize = 13.sp)
                Btn(if (startingZapupi || checkingZapupi) zapupiText("creating") else tx("ADD MONEY"), Modifier.fillMaxWidth(), color = if (validAmount) Orange else ButtonC, enabled = !startingZapupi && !checkingZapupi) {
                    if (online) startZapupiPayment(amount)
                    else if (amount < minValue) ctx.toast("${tx("Minimum amount")} ₹${money(minValue)}")
                    else if (amount > maxValue) ctx.toast("${tx("Maximum amount")} ₹${money(maxValue)}")
                    else nav.go("manualpay/${money(amount)}")
                }
                Text("${tx("Minimum amount")} ₹${money(minValue)}  •  ${tx("Maximum amount")} ₹${money(maxValue)}", Modifier.fillMaxWidth().padding(top = 10.dp), fontSize = 12.sp, color = Color.Gray, textAlign = TextAlign.Center)
                Text(if (online) zapupiText("verified_note") else tx("Manual payments are credited after admin approval."), Modifier.fillMaxWidth().padding(top = 6.dp), fontSize = 12.sp, color = Color.Gray, textAlign = TextAlign.Center)
            }
        }
    } else {
    // ---- NEW design (default): plain title, white amount field with coin icon, PAY NOW pill and a white notes box ----
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, null, Modifier.size(24.dp).clickable { nav.back() })
            Spacer(Modifier.width(16.dp))
            Text(tx("Add Coins"), fontSize = 19.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
        Spacer(Modifier.height(if (chipsEnabled.trim().equals("true", ignoreCase = true)) 24.dp else 44.dp))
        if (chipsEnabled.trim().equals("true", ignoreCase = true)) {
            Text(tx("Select amount"), fontSize = 18.sp, modifier = Modifier.padding(start = 19.dp, end = 19.dp, bottom = 12.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 19.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                chips.forEach { c ->
                    val on = amt == c
                    Box(Modifier.clip(RoundedCornerShape(8.dp)).background(if (on) ButtonC else Color.Transparent).border(1.dp, Color.White, RoundedCornerShape(8.dp))
                        .clickable { amt = c }.padding(horizontal = 16.dp, vertical = 14.dp), contentAlignment = Alignment.Center) {
                        Text(c, fontSize = 15.sp, color = if (on) Orange else Color.White)
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 19.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                HorizontalDivider(Modifier.weight(1f), color = Color.Gray); Text("   ${tx("OR")}   ", fontSize = 15.sp); HorizontalDivider(Modifier.weight(1f), color = Color.Gray)
            }
        }
        OutlinedTextField(amt, { amt = it.filter { ch -> ch.isDigit() || ch == '.' } }, Modifier.fillMaxWidth().padding(horizontal = 19.dp),
            placeholder = { Text(tx("Coins"), color = Color(0xFF1A1A1A), fontSize = 17.sp) },
            leadingIcon = { CoinIcon(26) },
            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 17.sp, color = Orange),
            shape = RoundedCornerShape(10.dp), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color.White, unfocusedContainerColor = Color.White,
                focusedTextColor = Orange, unfocusedTextColor = Orange, cursorColor = Orange,
                focusedBorderColor = Color(0xFF2A2A40), unfocusedBorderColor = Color(0xFF2A2A40)))
        Spacer(Modifier.height(16.dp))
        Box(Modifier.align(Alignment.CenterHorizontally).fillMaxWidth(0.45f).height(40.dp).clip(RoundedCornerShape(50))
            .background(Color(0xFF6200FF)).clickable(enabled = !startingZapupi && !checkingZapupi) {
                if (online) startZapupiPayment(amount)
                else if (amount < minValue) ctx.toast("${tx("Minimum amount")} ₹${money(minValue)}")
                else if (amount > maxValue) ctx.toast("${tx("Maximum amount")} ₹${money(maxValue)}")
                else nav.go("manualpay/${money(amount)}")
            }, contentAlignment = Alignment.Center) {
            Text(if (startingZapupi || checkingZapupi) tx("PROCESSING...") else tx("PAY NOW"), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(29.dp))
        Column(Modifier.fillMaxWidth().padding(horizontal = 15.dp).background(Color.White).padding(start = 15.dp, end = 12.dp, top = 16.dp, bottom = 36.dp)) {
            listOf(
                "Do not press back during payment.", "Wait till the payment gets confirmed.", "Payment is 100% secure.",
                "Accepts all payment methods.", "No hidden charges.", "Instant confirmation on successful payment.",
                "Contact support for any issues with transactions."
            ).forEach { Text("•  ${tx(it)}", color = Color.Black, fontSize = 13.sp, lineHeight = 17.sp) }
        }
        Spacer(Modifier.height(24.dp))
    }
    }
    if (showCheckout) zapupiOrder?.let { order ->
        ZapupiCheckoutDialog(order.paymentUrl) { showCheckout = false; finishPayment(order) }
    }
}

/** Manual UPI payment: shows the admin's UPI ID / QR, then the player enters the UTR and the admin approves it. */
@Composable
fun ManualDepositScreen(nav: NavController, amountArg: String) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val user by rflow(init = User()) { Repo.me() }
    val upi by rflow(init = "") { Repo.setting("upiId") }
    val qr by rflow(init = "") { Repo.setting("upiQr") }
    val payee by rflow(init = "") { Repo.setting("upiName") }
    val reqs by rflow(init = emptyList<DepositReq>()) { Repo.depositRequests() }
    val amount = amountArg.toDoubleOrNull() ?: 0.0
    var utr by remember { mutableStateOf("") }
    var shot by remember { mutableStateOf<Uri?>(null) }
    var busy by remember { mutableStateOf(false) }
    val f = remember { SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u -> if (u != null) shot = u }
    val validUtr = utr.isEmpty() || utr.length in 8..30
    val canSubmit = shot != null && validUtr
    Column(Modifier.fillMaxSize()) {
        BackBar(tx("Pay via UPI"), nav)
        Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("${tx("Pay")} ₹${money(amount)}", color = Orange, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            if (qr.isNotBlank()) AsyncImage(qr, null, Modifier.size(230.dp).clip(RoundedCornerShape(12.dp)).background(Color.White).padding(8.dp), contentScale = ContentScale.Fit)
            if (upi.isBlank()) {
                Text(tx("Payment details are not added yet. Please contact support."), Modifier.padding(vertical = 20.dp), color = Color.Gray, textAlign = TextAlign.Center)
            } else {
                Spacer(Modifier.height(12.dp))
                Row(Modifier.clip(RoundedCornerShape(10.dp)).background(CardC).padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(upi, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(12.dp))
                    Text(tx("Copy"), color = Orange, fontWeight = FontWeight.Bold, modifier = Modifier.clickable {
                        val cm = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                        cm.setPrimaryClip(android.content.ClipData.newPlainText("upi", upi)); ctx.toast(tx("UPI ID copied"))
                    })
                }
                Spacer(Modifier.height(12.dp))
                Btn(tx("OPEN UPI APP"), Modifier.fillMaxWidth()) {
                    val link = "upi://pay?pa=${Uri.encode(upi.trim())}&pn=${Uri.encode(payee.ifBlank { "BESTWIN ESPORTS" })}&am=${money(amount)}&cu=INR&tn=${Uri.encode("Wallet top-up")}"
                    try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link))) } catch (e: Exception) { ctx.toast(tx("Could not open a UPI app")) }
                }
            }
            HorizontalDivider(Modifier.padding(vertical = 20.dp), color = Color.Gray)
            Text(tx("After paying, attach the payment screenshot"), Modifier.fillMaxWidth(), fontSize = 14.sp)
            Spacer(Modifier.height(10.dp))
            shot?.let { AsyncImage(it, null, Modifier.fillMaxWidth().heightIn(max = 260.dp).clip(RoundedCornerShape(10.dp)), contentScale = ContentScale.Fit); Spacer(Modifier.height(10.dp)) }
            Btn(if (shot == null) tx("ATTACH SCREENSHOT") else tx("CHANGE SCREENSHOT"), Modifier.fillMaxWidth()) { picker.launch("image/*") }
            Spacer(Modifier.height(14.dp))
            LineField(utr, { utr = it.filter { c -> c.isLetterOrDigit() }.uppercase().take(30) }, tx("UTR / Transaction ID (optional)"))
            Spacer(Modifier.height(16.dp))
            Btn(if (busy) tx("PLEASE WAIT...") else tx("SUBMIT"), Modifier.fillMaxWidth(), color = if (canSubmit) Orange else ButtonC, enabled = !busy) {
                if (shot == null) ctx.toast(tx("Attach the payment screenshot"))
                else if (!validUtr) ctx.toast(tx("Enter a valid UTR / transaction ID"))
                else { busy = true; scope.launch {
                    val data = ProofImage.toDataUri(ctx, shot!!)
                    if (data == null) { busy = false; ctx.toast(tx("Could not read the screenshot. Choose another image.")) }
                    else {
                        val err = Repo.submitDeposit(amount, utr, user.username, data); busy = false
                        if (err == null) { ctx.toast(tx("Request sent. Your wallet will be credited after admin approval.")); nav.popBackStack() } else ctx.toast(err)
                    }
                } }
            }
            if (reqs.isNotEmpty()) {
                Text(tx("My deposit requests"), Modifier.fillMaxWidth().padding(top = 28.dp, bottom = 6.dp), fontWeight = FontWeight.Bold)
                reqs.take(8).forEach { q ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(10.dp)).background(CardC).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("₹${money(q.amount)}  •  ${q.utr}", fontSize = 13.sp)
                            if (q.ts > 0) Text(f.format(Date(q.ts)), fontSize = 11.sp, color = Color.Gray)
                        }
                        Text(tx(q.status.replaceFirstChar { it.uppercase() }), fontWeight = FontWeight.Bold, fontSize = 13.sp,
                            color = when (q.status) { "approved" -> Color(0xFF3DDC84); "rejected" -> Color(0xFFFF6B6B); else -> Orange })
                    }
                }
            }
        }
    }
}

private class WdMethod(val id: String, val title: String, val fee: Double, val hint: String)
private data class WithdrawSuccess(val amount: Double, val net: Double, val method: String, val destination: String, val methodId: String = "")

private fun pct(v: Double): String = if (v % 1.0 == 0.0) v.toInt().toString() else v.toString()

/** Withdraw money page. Methods, commission, limits and notes are all controlled from the admin app (Settings). */
@Composable
fun WithdrawScreen(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val user by rflow(init = User()) { Repo.me() }
    val cfg by rflow(init = emptyMap<String, Any?>()) { Repo.settings() }
    fun s(k: String, d: String): String = cfg[k]?.toString()?.takeIf { it.isNotBlank() } ?: d
    fun on(k: String): Boolean = !s(k, "true").trim().equals("false", ignoreCase = true)
    val methods = listOfNotNull(
        if (on("wdUpiEnabled")) WdMethod("upi", s("wdUpiTitle", "UPI ID"), s("wdUpiFee", "0").toDoubleOrNull() ?: 0.0, s("wdUpiHint", "UPI Id")) else null,
        if (on("wdGpEnabled")) WdMethod("gp", s("wdGpTitle", "Google Play Redeem Code"), s("wdGpFee", "20").toDoubleOrNull() ?: 20.0, s("wdGpHint", "Gmail ID")) else null,
        if (on("wdFpEnabled")) WdMethod("fp", s("wdFpTitle", "Fampay"), s("wdFpFee", "0").toDoubleOrNull() ?: 0.0, s("wdFpHint", "Fampay UPI Id")) else null
    )
    var selId by remember { mutableStateOf("") }
    val sel = methods.firstOrNull { it.id == selId } ?: methods.firstOrNull()
    var dest by remember { mutableStateOf("") }
    var amt by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var success by remember { mutableStateOf<WithdrawSuccess?>(null) }
    val minWd = s("minWithdraw", "50").toDoubleOrNull() ?: 50.0
    val maxWd = s("maxWithdraw", "10000").toDoubleOrNull() ?: 10000.0
    val amount = amt.toDoubleOrNull() ?: 0.0
    val fee = sel?.fee ?: 0.0
    val net = amount * (100.0 - fee) / 100.0
    val valid = sel != null && amount >= minWd && amount <= maxWd && amount <= user.winning && dest.isNotBlank()
    Column(Modifier.fillMaxSize()) {
        BackBar(tx("Withdraw Money"), nav)
        Column(Modifier.padding(horizontal = 24.dp, vertical = 20.dp).verticalScroll(rememberScrollState())) {
            if (sel == null) {
                Text(tx("Withdrawals are temporarily unavailable."), Modifier.fillMaxWidth().padding(top = 30.dp), color = Color.Gray, textAlign = TextAlign.Center)
            } else {
                Text("${tx("Withdraw to")} ${tx(sel.title)}", Modifier.fillMaxWidth(), fontWeight = FontWeight.SemiBold, fontSize = 14.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(14.dp))
                LineField(dest, { dest = it.trim() }, tx(sel.hint))
                Spacer(Modifier.height(14.dp))
                LineField(amt, { amt = it.filter { c -> c.isDigit() } }, tx("Amount"), kb = KeyboardType.Number)
                Spacer(Modifier.height(22.dp))
                Row(verticalAlignment = Alignment.Top) {
                    Text(tx("Withdraw to"), Modifier.padding(top = 12.dp), fontSize = 14.sp)
                    Spacer(Modifier.width(14.dp))
                    Column {
                        methods.forEach { m ->
                            Row(Modifier.clickable { selId = m.id }, verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(sel.id == m.id, { selId = m.id }, colors = RadioButtonDefaults.colors(selectedColor = Orange))
                                Text(tx(m.title) + if (m.fee > 0) " ( ${pct(m.fee)}% ${tx("Commission Cut")} )" else "", fontSize = 13.sp)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(14.dp))
                Text(if (amount > 0) "${tx("You will get")} ₹${money(net)}" else " ", Modifier.fillMaxWidth(), color = Orange, textAlign = TextAlign.Center, fontSize = 13.sp)
                Spacer(Modifier.height(14.dp))
                // Always reads WITHDRAW MONEY (never "PLEASE WAIT..." / grey); a second tap while the request runs is simply ignored.
                Btn(tx("WITHDRAW MONEY"), Modifier.fillMaxWidth(), color = if (valid) Orange else ButtonC) {
                    if (busy) return@Btn
                    when {
                        amount < minWd -> ctx.toast("${tx("Minimum withdraw")} ₹${money(minWd)}")
                        amount > maxWd -> ctx.toast("${tx("Maximum withdraw")} ₹${money(maxWd)}")
                        amount > user.winning -> ctx.toast(tx("Only winning balance can be withdrawn"))
                        dest.isBlank() -> ctx.toast(tx("Enter a valid ID"))
                        else -> {
                            val method = sel
                            val destination = dest.trim()
                            val requestedAmount = amount
                            val requestedNet = net
                            busy = true; scope.launch {
                            val err = Repo.requestWithdraw(requestedAmount, destination, user.username, method.id, method.title, method.fee); busy = false
                            if (err == null) {
                                amt = ""
                                dest = ""
                                success = WithdrawSuccess(requestedAmount, requestedNet, method.title, destination, method.id)
                            } else ctx.toast(err)
                        } }
                    }
                }
                Text(tx(s("withdrawNote", "You can only withdraw win money.")), Modifier.fillMaxWidth().padding(top = 36.dp), fontSize = 13.sp, textAlign = TextAlign.Center)
            }
        }
    }
    androidx.activity.compose.BackHandler(success != null) { success = null; nav.popBackStack() }
    success?.let { result ->
        WithdrawSuccessCard(result) { success = null; nav.popBackStack() }
    }
}

// Fixed (permanent) colours for the withdraw success card - they do NOT change with the app theme.
private val WsCard = Color(0xFF1A0B3B)
private val WsBlock = Color(0xFF2B1657)
private val WsBorder = Color(0xFF7C3AED)
private val WsGreen = Color(0xFF3DDC84)
private val WsGold = Color(0xFFFFB300)
private val WsText = Color(0xFFFFFFFF)
private val WsSub = Color(0xFFD1C4E9)

/** Square success card shown after a withdraw request. Every line sits in its own text block. */
@Composable
private fun WithdrawSuccessCard(result: WithdrawSuccess, onOk: () -> Unit) {
    androidx.compose.ui.window.Dialog(
        onDismissRequest = onOk,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
    ) {
        BoxWithConstraints(Modifier.fillMaxWidth().padding(horizontal = 32.dp), contentAlignment = Alignment.Center) {
            val side = maxWidth
            Column(
                Modifier.fillMaxWidth().heightIn(min = side)
                    .clip(RoundedCornerShape(10.dp))
                    .background(WsCard)
                    .border(2.dp, WsBorder, RoundedCornerShape(10.dp))
                    .padding(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = WsGreen, modifier = Modifier.size(34.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(tx("Withdrawal Requested"), color = WsText, fontWeight = FontWeight.Bold, fontSize = 18.sp, textAlign = TextAlign.Center)
                }
                Spacer(Modifier.height(10.dp))
                // Block 1 - amount
                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(WsBlock).padding(vertical = 10.dp), contentAlignment = Alignment.Center) {
                    Text("\u20B9${money(result.amount)}", color = WsGold, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                }
                Spacer(Modifier.height(8.dp))
                // Block 2 - message
                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(WsBlock).padding(10.dp), contentAlignment = Alignment.Center) {
                    Text(
                        tx("You will receive") + " \u20B9${money(result.net)} ${tx("within 24 hours through")} ${tx(result.method)}.",
                        color = WsText, fontSize = 14.sp, textAlign = TextAlign.Center
                    )
                }
                Spacer(Modifier.height(8.dp))
                // Block 3 - account
                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(WsBlock).padding(10.dp), contentAlignment = Alignment.Center) {
                    val accLabel = when (result.methodId) {
                        "upi" -> "UPI Account"
                        "gp" -> "Google Email"
                        "fp" -> "Fampay Account"
                        else -> tx(result.method)
                    }
                    Text("$accLabel: ${result.destination}", color = WsSub, fontSize = 13.sp, textAlign = TextAlign.Center)
                }
                Spacer(Modifier.height(12.dp))
                Box(
                    Modifier.fillMaxWidth().height(46.dp).clip(RoundedCornerShape(6.dp)).background(WsGreen).clickable(onClick = onOk),
                    contentAlignment = Alignment.Center
                ) { Text("OK", color = Color(0xFF0B1F12), fontWeight = FontWeight.ExtraBold, fontSize = 16.sp) }
            }
        }
    }
}

@Composable
fun WalletScreen(nav: NavController) {
    val u by rflow(init = User()) { Repo.me() }
    val tour = remember { WalletTourState() }
    // Admin choice (Settings -> "My Wallet page design"): "old" = the old black-bar wallet page, anything else = the NEW page (default).
    // The last value is kept on the phone so the page never flips from one design to the other while opening.
    val wCtx = LocalContext.current
    val uiPrefs = remember { wCtx.getSharedPreferences("ui_prefs", android.content.Context.MODE_PRIVATE) }
    val styleRaw by rflow(init = uiPrefs.getString("walletStyle", "") ?: "") { Repo.setting("walletStyle") }
    LaunchedEffect(styleRaw) { uiPrefs.edit().putString("walletStyle", styleRaw).apply() }
    val oldStyle = styleRaw.trim().equals("old", ignoreCase = true)
    Box(Modifier.fillMaxSize()) {
        if (oldStyle) OldWalletPage(nav, u, tour)
        else Column(Modifier.fillMaxSize()) { BackBar(tx("My Wallet"), nav); WalletTab(nav, u, tour) }
        WalletTour(tour)   // first-time spotlight on Add Coins / Withdraw (works in both designs)
    }
}

@Composable
fun HistoryScreen(nav: NavController) {
    val listN by rflow(init = null as List<Tx>?) { Repo.txs() }
    val f = remember { SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()) }
    Column(Modifier.fillMaxSize()) {
        BackBar(tx("Transactions"), nav)
        val list = listN ?: return@Column Loader()
        if (list.isEmpty()) Text(tx("No transactions yet"), Modifier.fillMaxWidth().padding(40.dp), textAlign = TextAlign.Center, color = Color.Gray)
        LazyColumn(contentPadding = PaddingValues(12.dp)) {
            items(list) { t ->
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF141416))   // fixed light-black card (#141416), same in every theme
                        .padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(t.note, fontWeight = FontWeight.SemiBold, fontSize = 14.sp); Text(f.format(Date(t.ts)) + "  •  " + t.status, color = Color.Gray, fontSize = 12.sp)
                    }
                    Text((if (t.amount >= 0) "+" else "") + money(t.amount), color = if (t.amount >= 0) SuccessC else Red, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            }
        }
    }
}

private const val DEFAULT_ABOUT = "BESTWIN ESPORTS is a tournament platform where players join daily matches, compete and win prizes based on their performance."
private const val DEFAULT_TERMS = "1. You must be 18 years or older to play.\n2. One person, one account. Duplicate or fake accounts will be banned.\n3. Hacks, teaming or any unfair play leads to disqualification and a ban.\n4. Entry fees are non-refundable once a match starts.\n5. Only winning balance can be withdrawn.\n6. Management decisions on results are final."

@Composable
fun InfoScreen(nav: NavController, key: String, title: String) {
    val text by rflow(key, init = "") { Repo.setting("page_$key") }
    val body = brandAppName(text.ifBlank { when (key) { "about" -> DEFAULT_ABOUT; "terms" -> DEFAULT_TERMS; else -> tx("Content will be updated soon.") } })
    Column(Modifier.fillMaxSize()) {
        BackBar(tx(title), nav)
        Text(body, Modifier.padding(16.dp).verticalScroll(rememberScrollState()), fontSize = 15.sp, lineHeight = 23.sp)
    }
}

/** My Statistics: table of every match this player has PLAYED (all time): # | Match Info | Paid | Won. */
@Composable
fun StatsScreen(nav: NavController) {
    val u by rflow(init = User()) { Repo.me() }
    val allN by rflow(init = null as List<Match>?) { Repo.myMatches() }
    val played = allN?.filter { it.status == "completed" }.orEmpty()
    Column(Modifier.fillMaxSize()) {
        BackBar(tx("My Statistics"), nav)
        Row(Modifier.fillMaxWidth().background(glassOr(Color(0xFF1B0035))).padding(vertical = 12.dp, horizontal = 10.dp)) {
            Text("#", Modifier.width(26.dp), fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(tx("Match Info"), Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(tx("Paid"), Modifier.width(56.dp), fontWeight = FontWeight.Bold, fontSize = 14.sp, textAlign = TextAlign.Center)
            Text(tx("Won"), Modifier.width(56.dp), fontWeight = FontWeight.Bold, fontSize = 14.sp, textAlign = TextAlign.Center)
        }
        if (allN == null) Loader()
        else if (played.isEmpty()) EmptyMatches("completed")
        else LazyColumn(Modifier.fillMaxSize()) {
            itemsIndexed(played, key = { _, m -> m.id }) { i, m -> StatRow(i + 1, m, u.username) }
        }
    }
}

@Composable
private fun StatRow(n: Int, m: Match, username: String) {
    val res by rflow(m.id, m.archived, init = null as List<Res>?) { if (m.archived) Repo.savedResults(m.id) else Repo.results(m.id) }
    val won = res?.filter { it.username.equals(username, ignoreCase = true) }?.sumOf { it.prize }
    val ink = Color(0xFF2B2B2B)
    Row(Modifier.fillMaxWidth().background(Color.White).padding(vertical = 8.dp, horizontal = 10.dp), verticalAlignment = Alignment.Top) {
        Text("$n", Modifier.width(26.dp), fontSize = 13.sp, color = ink)
        Column(Modifier.weight(1f)) {
            Text("${m.title} - Match #${m.matchNo}", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = ink, maxLines = 2, lineHeight = 17.sp)
            Text(matchDate(m.startTime).lowercase(), fontSize = 11.sp, color = Color(0xFF555555))
        }
        Text(money(m.fee()), Modifier.width(56.dp), fontSize = 13.sp, color = ink, textAlign = TextAlign.Center)
        Text(won?.let { money(it) } ?: "-", Modifier.width(56.dp), fontSize = 13.sp, color = ink, textAlign = TextAlign.Center)
    }
    HorizontalDivider(color = Color(0xFFE0E0E0))
}

@Composable
private fun StatBox(icon: ImageVector, value: String, label: String, modifier: Modifier) {
    Column(modifier.clip(RoundedCornerShape(12.dp)).background(CardC).padding(14.dp)) {
        Icon(icon, null, tint = Red, modifier = Modifier.size(24.dp)); Spacer(Modifier.height(8.dp))
        Text(value, fontSize = 20.sp, fontWeight = FontWeight.Bold); Text(label, color = Color.Gray, fontSize = 12.sp)
    }
}

/** Announcements page: one rounded card per announcement (same colour as the Home Ongoing / Upcoming / Completed boxes, white text) - title first, then the full message in the same card. */
@Composable
fun AnnouncementScreen(nav: NavController) {
    val listN by rflow(init = null as List<Ann>?) { Repo.announcements() }
    Column(Modifier.fillMaxSize()) {
        BackBar(tx("Announcement"), nav)
        val list = listN ?: return@Column Loader()
        if (list.isEmpty()) Text(tx("No announcements"), Modifier.fillMaxWidth().padding(40.dp), textAlign = TextAlign.Center, color = Color.Gray)
        LazyColumn(contentPadding = PaddingValues(horizontal = 6.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(list, key = { it.id }) { a ->
                val title = brandAppName(a.title).trim(); val msg = brandAppName(a.text).trim()
                val body = if (title.isNotBlank() && msg.isNotBlank()) "$title\n\n$msg" else title.ifBlank { msg }
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(HomeBoxC).padding(horizontal = 16.dp, vertical = 14.dp)) {   // same colour as the Home Ongoing / Upcoming / Completed boxes
                    if (a.image.isNotBlank()) AsyncImage(a.image, null, Modifier.fillMaxWidth().padding(bottom = 10.dp).clip(RoundedCornerShape(10.dp)), contentScale = ContentScale.FillWidth)
                    Text(body, color = Color.White, fontSize = 15.sp, lineHeight = 22.sp)
                }
            }
        }
    }
}

@Composable
fun ProfileScreen(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val u by rflow(init = User()) { Repo.me() }
    val logo by rflow(init = "") { Repo.setting("logoUrl") }
    var first by remember(u.firstName) { mutableStateOf(u.firstName) }
    var last by remember(u.lastName) { mutableStateOf(u.lastName) }
    var dob by remember(u.dob) { mutableStateOf(u.dob) }
    var gender by remember(u.gender) { mutableStateOf(u.gender) }
    var oldPw by remember { mutableStateOf("") }; var newPw by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        BackBar(tx("My Profile"), nav)
        Column(Modifier.verticalScroll(rememberScrollState()).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(96.dp).padding(3.dp)) { ProfileLogo(logo, 90) }
            Spacer(Modifier.height(18.dp))
            LineField(first, { first = it }, tx("First Name *")); Spacer(Modifier.height(6.dp))
            LineField(last, { last = it }, tx("Last Name")); Spacer(Modifier.height(6.dp))
            LineField(u.username, {}, tx("Username *"), enabled = false); Spacer(Modifier.height(6.dp))
            LineField(u.email, {}, tx("Email *"), enabled = false); Spacer(Modifier.height(6.dp))
            LineField(u.phone, {}, tx("Mobile Number *"), enabled = false); Spacer(Modifier.height(6.dp))
            Box {
                LineField(dob, {}, tx("Date of Birth"), enabled = false)
                Box(Modifier.matchParentSize().clickable {
                    val c = Calendar.getInstance()
                    DatePickerDialog(ctx, { _, y, m, d -> dob = "%02d/%02d/%04d".format(d, m + 1, y) }, c.get(Calendar.YEAR) - 18, c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
                })
            }
            Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(tx("Gender"), Modifier.padding(end = 12.dp), color = Color.Gray, fontSize = 14.sp)
                listOf("Male", "Female").forEach { g ->
                    RadioButton(gender == g, { gender = g }, colors = RadioButtonDefaults.colors(selectedColor = Orange)); Text(g, fontSize = 14.sp, modifier = Modifier.padding(end = 10.dp))
                }
            }
            Spacer(Modifier.height(10.dp))
            Btn(tx("UPDATE PROFILE"), Modifier.fillMaxWidth()) {
                if (first.isBlank()) ctx.toast(tx("First name is required"))
                else scope.launch { ctx.toast(Repo.updateProfile(first, last, dob, gender) ?: tx("Profile updated")) }
            }
            Spacer(Modifier.height(22.dp))
            Text(tx("Reset Password"), Modifier.fillMaxWidth(), fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Orange)
            Spacer(Modifier.height(6.dp))
            LineField(oldPw, { oldPw = it }, tx("Old Password"), pw = true); Spacer(Modifier.height(6.dp))
            LineField(newPw, { newPw = it }, tx("New Password"), pw = true)
            Spacer(Modifier.height(14.dp))
            Btn(tx("RESET PASSWORD"), Modifier.fillMaxWidth()) {
                if (oldPw.isBlank() || newPw.length < 6) ctx.toast(tx("Enter old password and a new one (min 6)"))
                else scope.launch { val e = Repo.changePassword(oldPw, newPw); ctx.toast(e ?: tx("Password changed")); if (e == null) { oldPw = ""; newPw = "" } }
            }
        }
    }
}

// ---------------- Support / Tutorial ----------------
private class SupportRow(val label: String, val value: String, val kind: String, val shown: String = value)

private val embeddedLink = Regex("(https?://\\S+|@[A-Za-z0-9_]{4,})")

/** Customer Support page: simple lines (Address, Email, Instagram ...) written by the admin in Admin -> Settings. Tapping a line opens it. */
@Composable
fun SupportScreen(nav: NavController) {
    val ctx = LocalContext.current
    val address by rflow(init = "") { Repo.setting("supportAddress") }
    val email by rflow(init = "") { Repo.setting("supportEmail") }
    val insta by rflow(init = "") { Repo.setting("supportInstagram") }
    val tg by rflow(init = "") { Repo.setting("supportTelegram") }
    val wa by rflow(init = "") { Repo.setting("supportWhatsapp") }
    val phone by rflow(init = "") { Repo.setting("supportPhone") }
    val street by rflow(init = "") { Repo.setting("supportStreet") }
    val time by rflow(init = "") { Repo.setting("supportTime") }
    val instaName by rflow(init = "") { Repo.setting("supportInstagramName") }
    val tgName by rflow(init = "") { Repo.setting("supportTelegramName") }
    val waName by rflow(init = "") { Repo.setting("supportWhatsappName") }
    val rows = listOf(
        SupportRow(tr("address"), address, "text"), SupportRow(tr("email"), email, "email"), SupportRow(tr("instagram"), insta, "instagram", instaName.ifBlank { insta }),
        SupportRow(tr("telegram"), tg, "telegram", tgName.ifBlank { tg }), SupportRow(tr("whatsapp"), wa, "whatsapp", waName.ifBlank { wa }), SupportRow(tr("phone"), phone, "phone"),
        SupportRow(tr("street"), street, "text"), SupportRow(tr("hours"), time, "text")
    ).filter { it.value.isNotBlank() }
    Column(Modifier.fillMaxSize()) {
        BackBar(tr("customer_support"), nav)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 6.dp)) {
            if (rows.isEmpty()) Text(tr("support_empty"), Modifier.fillMaxWidth().padding(40.dp), color = Color.Gray, textAlign = TextAlign.Center)
            rows.forEach { r ->
                val inside = if (r.kind == "text") embeddedLink.find(r.value)?.value else null
                val tappable = r.kind != "text" || inside != null
                Row(Modifier.fillMaxWidth().clickable(enabled = tappable) { ctx.openLink(inside ?: r.value, if (r.kind == "text") "auto" else r.kind, nav) }.padding(horizontal = 8.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Text("${r.label} : ${r.shown}", Modifier.weight(1f), fontSize = 14.sp)
                    when (r.kind) {
                        "email" -> Box(Modifier.size(30.dp).clip(RoundedCornerShape(6.dp)).background(Color(0xFF5CCFB3)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Email, null, tint = Color.Black, modifier = Modifier.size(19.dp)) }
                        "instagram" -> Box(Modifier.size(32.dp).clip(CircleShape).background(androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color(0xFFFEDA75), Color(0xFFD62976), Color(0xFF4F5BD5)))), contentAlignment = Alignment.Center) {
                            Icon(androidx.compose.ui.res.painterResource(R.drawable.ic_instagram), null, tint = Color.White, modifier = Modifier.size(19.dp)) }
                        "telegram" -> Box(Modifier.size(32.dp).clip(CircleShape).background(Color(0xFF229ED9)), contentAlignment = Alignment.Center) {
                            Icon(androidx.compose.ui.res.painterResource(R.drawable.ic_telegram), null, tint = Color.White, modifier = Modifier.size(19.dp)) }
                        "whatsapp" -> Box(Modifier.size(32.dp).clip(CircleShape).background(Color(0xFF25D366)), contentAlignment = Alignment.Center) {
                            Icon(androidx.compose.ui.res.painterResource(R.drawable.ic_whatsapp), null, tint = Color.White, modifier = Modifier.size(19.dp)) }
                        "phone" -> Box(Modifier.size(32.dp).clip(CircleShape).background(Color(0xFF21A366)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Call, null, tint = Color.White, modifier = Modifier.size(18.dp)) }
                        else -> if (inside != null) Icon(Icons.AutoMirrored.Filled.ArrowForward, null, tint = Color.Gray, modifier = Modifier.size(20.dp))
                    }
                }
                HorizontalDivider(color = Color(0xFF555555))
            }
        }
    }
}

@Composable
fun TutorialScreen(nav: NavController) {
    val urlN by rflow(init = null as String?) { Repo.setting("tutorialUrl") }
    val uri = LocalUriHandler.current
    Column(Modifier.fillMaxSize()) {
        BackBar(tx("App Tutorial"), nav)
        val url = urlN?.trim()
        when {
            url == null -> Loader()
            // Admin has not added a tutorial link yet: only "Data not found" is shown (no video box, no button).
            url.isBlank() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(tx("Data not found"), color = Color.Gray, fontSize = 16.sp, textAlign = TextAlign.Center)
            }
            else -> {
                val id = Regex("(?:v=|youtu\\.be/|embed/)([A-Za-z0-9_-]{11})").find(url)?.groupValues?.get(1)
                Column(Modifier.padding(16.dp).fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(CardC).padding(16.dp)) {
                    Text(tx("App Setup Tutorial"), color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.height(12.dp))
                    Box(Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF1B1B1B)).clickable { uri.openUri(url) }, contentAlignment = Alignment.Center) {
                        if (id != null) AsyncImage("https://img.youtube.com/vi/$id/hqdefault.jpg", null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        Icon(Icons.Default.PlayCircle, null, tint = Color.White, modifier = Modifier.size(54.dp))
                    }
                    Spacer(Modifier.height(14.dp))
                    Btn(tx("WATCH TUTORIAL VIDEO"), Modifier.fillMaxWidth(), SupportC) { uri.openUri(url) }
                }
            }
        }
    }
}

// ---------------- Referral / Rewards ----------------
@Composable
fun ReferScreen(nav: NavController) {
    val u by rflow(init = User()) { Repo.me() }
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    Column(Modifier.fillMaxSize()) {
        BackBar(tx("Refer & Earn"), nav)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(22.dp))
            Text(tx("REFER MORE TO EARN MORE"), color = Orange, fontSize = 20.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
            Spacer(Modifier.height(6.dp))
            Text(tx("Invite your friends and earn rewards when they play"), fontSize = 14.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(26.dp))
            Text(tx("YOUR REFERRAL CODE"), color = Orange, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.clip(RoundedCornerShape(8.dp)).border(1.dp, Color.White, RoundedCornerShape(8.dp)).padding(horizontal = 18.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(u.referralCode.uppercase(), fontSize = 17.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.width(12.dp))
                Icon(Icons.Default.ContentCopy, null, Modifier.size(20.dp).clickable { clip.setText(AnnotatedString(u.referralCode)); ctx.toast(tx("Code copied")) })
            }
            Spacer(Modifier.height(30.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                listOf(Icons.Default.Edit to tx("Friends sign up with your code"), Icons.Default.SportsEsports to tx("They play matches"), Icons.Default.CardGiftcard to tx("You earn rewards")).forEachIndexed { i, (ic, t) ->
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(Modifier.size(54.dp).clip(CircleShape).background(Color(0xFF2B5BE8)), contentAlignment = Alignment.Center) { Icon(ic, null, Modifier.size(26.dp)) }
                        Spacer(Modifier.height(6.dp)); Text(t, fontSize = 11.sp, textAlign = TextAlign.Center)
                    }
                    if (i < 2) Icon(Icons.AutoMirrored.Filled.ArrowForward, null, Modifier.size(18.dp), tint = Color.Gray)
                }
            }
            Spacer(Modifier.height(36.dp))
            Btn(tx("REFER NOW"), Modifier.fillMaxWidth()) {
                ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, "Join BESTWIN ESPORTS and win real prizes! Use my referral code ${u.referralCode.uppercase()} while signing up.") }, "Share"))
            }
        }
    }
}

@Composable
fun ReferralsScreen(nav: NavController) {
    val u by rflow(init = User()) { Repo.me() }
    val list by rflow(init = emptyList<Referral>()) { Repo.referrals() }
    val f = remember { SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        BackBar(tx("My Referrals"), nav)
        SummaryCard(tx("MY REFERRALS SUMMARY"), tx("Referrals") to "${list.size}", "Earnings" to money(u.referralEarnings))
        TableCard(tx("REFERRAL DETAILS"), listOf(tx("Date"), tx("Player Name"), tx("Status")), list.map { listOf(f.format(Date(it.ts)), it.username, it.status.replaceFirstChar { c -> c.uppercase() }) }, tx("No Referrals Found."))
    }
}

@Composable
fun RewardsScreen(nav: NavController) {
    val list by rflow(init = emptyList<Reward>()) { Repo.rewards() }
    val f = remember { SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        BackBar(tx("My Rewards"), nav)
        SummaryCard(tx("MY REWARDS SUMMARY"), tx("Rewards") to "${list.size}", "Earnings" to money(list.sumOf { it.amount }))
        TableCard(tx("REWARD DETAILS"), listOf(tx("Date"), tx("Reward"), tx("Amount")), list.map { listOf(f.format(Date(it.ts)), it.title, money(it.amount)) }, tx("No Rewards Found."))
    }
}


/** Top Players: a strip of game cards (same size for every game) + the best players of the selected game for the current cycle.
 *  How many players are listed is set by the admin (Admin -> Leaderboard -> "Players per game", default 10). */
@Composable
fun LeaderboardScreen(nav: NavController) {
    val period by rflow(init = "weekly") { Repo.lbPeriod() }
    val topN by rflow(init = 10) { Repo.lbTopN() }
    val key = remember(period) { lbKey(period) }
    val gamesN by rflow(init = null as List<Game>?) { Repo.allGames() }
    var selId by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(BgBrush)) {
        BackBar(tx("Top Players"), nav)
        val games = gamesN
        if (games == null) { Loader(); return@Column }
        if (games.isEmpty()) { Text(tx("Match not found"), Modifier.fillMaxWidth().padding(48.dp), textAlign = TextAlign.Center, color = Color.Gray, fontSize = 16.sp); return@Column }
        val sel = games.firstOrNull { it.id == selId } ?: games.first()
        val listN by rflow(key, sel.id, topN, init = null as List<LBE>?) { Repo.lbTopGame(sel.id, topN) }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            // Game strip: picture-only square tiles (the game title is already part of the picture), every tile exactly the same size.
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 5.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                games.forEach { g ->
                    AsyncImage(g.image, null, Modifier.size(80.dp).clip(RoundedCornerShape(12.dp)).clickable { selId = g.id }, contentScale = ContentScale.Crop)
                }
            }
            Column(Modifier.padding(horizontal = 5.dp, vertical = 2.dp).clip(RoundedCornerShape(6.dp)).background(Color.White)) {
                Box(Modifier.fillMaxWidth().height(38.dp).background(glassOr(Color(0xFF22283C))), contentAlignment = Alignment.Center) {
                    Text(sel.name.uppercase(), color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                }
                Row(Modifier.fillMaxWidth().height(38.dp).background(glassOr(Color(0xFF021C3B))).padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(tx("User Name"), Modifier.weight(1f), color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Text(tx("Winning"), Modifier.width(100.dp), color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                }
                val list = listN
                if (list == null) Box(Modifier.fillMaxWidth().height(80.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp) }
                else if (list.isEmpty()) Text(tx("No winners yet"), Modifier.fillMaxWidth().padding(20.dp), color = Color.Gray, fontSize = 12.sp, textAlign = TextAlign.Center)
                else list.take(topN).forEach { r ->
                    Row(Modifier.fillMaxWidth().height(42.dp).padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(r.username, Modifier.weight(1f), color = Color(0xFF333333), fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                        Row(Modifier.width(100.dp), verticalAlignment = Alignment.CenterVertically) {
                            CoinIcon(16); Spacer(Modifier.width(6.dp))
                            Text(money(r.score), color = Color(0xFF333333), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                    HorizontalDivider(color = Color(0xFFDDDDDD), thickness = 0.5.dp)
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}


/** Leaderboard (referrals): every player who invited others, ranked by how many signed up with their referral code. Top 10. */
@Composable
fun ReferralBoardScreen(nav: NavController) {
    val listN by rflow(init = null as List<Pair<String, Long>>?) { Repo.refTop() }
    Column(Modifier.fillMaxSize().background(BgBrush)) {
        BackBar(tx("Leaderboard"), nav)
        Row(Modifier.fillMaxWidth().height(38.dp).background(glassOr(Color(0xFF1B0035))), verticalAlignment = Alignment.CenterVertically) {
            Text(tx("Username"), Modifier.weight(1.08f), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(tx("Total Referral"), Modifier.weight(0.92f), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
        val list = listN
        if (list == null) { Loader(); return@Column }
        if (list.isEmpty()) Text(tx("No referrals yet"), Modifier.fillMaxWidth().padding(40.dp), textAlign = TextAlign.Center, color = Color.Gray)
        Column(Modifier.verticalScroll(rememberScrollState())) {
            list.take(10).forEach { (name, n) ->
                Row(Modifier.fillMaxWidth().height(38.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(name, Modifier.weight(1.08f).padding(horizontal = 6.dp), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                    Text("$n", Modifier.weight(0.92f), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
                HorizontalDivider(color = Color(0xFFCCCCCC), thickness = 1.dp)
            }
        }
    }
}
