@file:androidx.media3.common.util.UnstableApi

package com.bestwinesport.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.foundation.background
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

class MainActivity : ComponentActivity() {
    /** Screen a tapped notification wants to open (voice message push -> Account -> Voice messages). */
    var pendingRoute by mutableStateOf<String?>(null)

    private fun readRoute(i: android.content.Intent?) { pendingRoute = i?.getStringExtra("open_route")?.takeIf { it == "voicemessages" } }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readRoute(intent)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        readRoute(intent)
        if (android.os.Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        AppLanguage.load(this)
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(android.app.NotificationManager::class.java)
            nm.createNotificationChannel(android.app.NotificationChannel("bestwin_default", "BESTWIN ESPORTS", android.app.NotificationManager.IMPORTANCE_HIGH))
        }
        setContent {
            val direction = if (AppLanguage.isRtl) androidx.compose.ui.unit.LayoutDirection.Rtl else androidx.compose.ui.unit.LayoutDirection.Ltr
            androidx.compose.runtime.CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides direction) {
                BestwinTheme { Surface(Modifier.fillMaxSize().background(BgBrush), color = androidx.compose.ui.graphics.Color.Transparent, contentColor = androidx.compose.ui.graphics.Color.White) { androidx.compose.foundation.layout.Box(Modifier.fillMaxSize()) { AppGate { AppNav() }; OfflineGate() } } }
            }
        }
    }

}

@Composable
fun AppNav() {
    val nav = rememberNavController()
    val activity = androidx.compose.ui.platform.LocalContext.current as? MainActivity
    val navEntry by nav.currentBackStackEntryAsState()
    // A tapped voice-message notification opens the voice list as soon as the player is inside the app (after splash / login).
    androidx.compose.runtime.LaunchedEffect(activity?.pendingRoute, navEntry?.destination?.route) {
        val r = activity?.pendingRoute
        if (r != null && navEntry?.destination?.route == "main") {
            nav.navigate(r) { launchSingleTop = true }
            activity.pendingRoute = null
        }
    }
    androidx.compose.foundation.layout.Box(Modifier.fillMaxSize()) {
    NavHost(nav, "splash",
        enterTransition = { slideIntoContainer(androidx.compose.animation.AnimatedContentTransitionScope.SlideDirection.Start, androidx.compose.animation.core.tween(220, easing = androidx.compose.animation.core.FastOutSlowInEasing)) + androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(160)) },
        exitTransition = { slideOutOfContainer(androidx.compose.animation.AnimatedContentTransitionScope.SlideDirection.Start, androidx.compose.animation.core.tween(220, easing = androidx.compose.animation.core.FastOutSlowInEasing), targetOffset = { it / 4 }) + androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(160)) },
        popEnterTransition = { slideIntoContainer(androidx.compose.animation.AnimatedContentTransitionScope.SlideDirection.End, androidx.compose.animation.core.tween(220, easing = androidx.compose.animation.core.FastOutSlowInEasing), initialOffset = { it / 4 }) + androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(160)) },
        popExitTransition = { slideOutOfContainer(androidx.compose.animation.AnimatedContentTransitionScope.SlideDirection.End, androidx.compose.animation.core.tween(220, easing = androidx.compose.animation.core.FastOutSlowInEasing)) + androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(160)) }
    ) {
        composable("splash") { SplashScreen(nav) }
        composable("lang") { Pad { LanguageScreen(nav) } }
        composable("welcome") { Pad { WelcomeScreen(nav) } }
        composable("login") { Pad { LoginScreen(nav) } }
        composable("signup") { Pad { SignupScreen(nav) } }
        composable("main") { MainScreen(nav) }
        composable("games/{s}") { Pad { GamesScreen(nav, it.arguments?.getString("s") ?: "freefire") } }
        composable("pvp") { Pad { PvpHubScreen(nav) } }
        composable("pvpmatch/{id}") { Pad { PvpMatchScreen(nav, it.arguments?.getString("id") ?: "") } }
        composable("matches/{g}") { Pad { MatchListScreen(nav, it.arguments?.getString("g") ?: "") } }
        composable("match/{id}") { Pad { MatchDetailScreen(nav, it.arguments?.getString("id") ?: "") } }
        composable("pick/{id}") { Pad { PickScreen(nav, it.arguments?.getString("id") ?: "") } }
        composable("myresult/{id}") { Pad { MyResultScreen(nav, it.arguments?.getString("id") ?: "") } }
        composable("mymatches/{t}") { Pad { MyMatchesScreen(nav, it.arguments?.getString("t") ?: "upcoming") } }
        composable("addmoney") { Pad { AddMoneyScreen(nav) } }
        composable("withdraw") { Pad { WithdrawScreen(nav) } }
        composable("manualpay/{amount}") { Pad { ManualDepositScreen(nav, it.arguments?.getString("amount") ?: "0") } }
        composable("wallet") { Pad { WalletScreen(nav) } }
        composable("history") { Pad { HistoryScreen(nav) } }
        composable("stats") { Pad { StatsScreen(nav) } }
        composable("profile") { Pad { ProfileScreen(nav) } }
        composable("support") { Pad { SupportScreen(nav) } }
        composable("faq") { Pad { FaqScreen(nav) } }
        composable("newticket") { Pad { NewSupportTicketScreen(nav) } }
        composable("mytickets") { Pad { MySupportTicketsScreen(nav) } }
        composable("ticket/{id}") { Pad { SupportTicketDetailScreen(nav, it.arguments?.getString("id") ?: "") } }
        composable("tutorial") { Pad { TutorialScreen(nav) } }
        composable("refer") { Pad { ReferScreen(nav) } }
        composable("referrals") { Pad { ReferralsScreen(nav) } }
        composable("rewards") { Pad { RewardsScreen(nav) } }
        composable("spin") { Pad { SpinScreen(nav) } }
        composable("spinhistory") { Pad { SpinHistoryScreen(nav) } }
        composable("leaderboard") { Pad { LeaderboardScreen(nav) } }
        composable("refboard") { Pad { ReferralBoardScreen(nav) } }
        composable("announcements") { Pad { AnnouncementScreen(nav) } }
        composable("worldchat") { Pad { WorldChatScreen(nav) } }
        composable("voicemessages") { Pad { VoiceMessagesScreen(nav) } }
        composable("announcement/{id}") { Pad { AnnouncementScreen(nav) } }
        composable("info/{k}/{t}") { Pad { InfoScreen(nav, it.arguments?.getString("k") ?: "", it.arguments?.getString("t") ?: "") } }
    }
    AdminPopupHost(nav)
    }
}

/** Screens other than the main tabs keep their content clear of the system bars (and the keyboard); the theme background still shows behind the bars. */
@Composable
fun Pad(content: @Composable () -> Unit) {
    androidx.compose.foundation.layout.Box(
        Modifier.fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) { content() }
}
