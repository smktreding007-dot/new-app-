package com.bestwinesport.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.CheckCircle as CheckCircleOutlined
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.layout
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import com.google.firebase.messaging.FirebaseMessaging

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MainScreen(nav: NavController) {
    val ctx = LocalContext.current
    val pager = rememberPagerState(initialPage = 1, pageCount = { 3 })
    val scope = rememberCoroutineScope()
    var lastBack by remember { mutableLongStateOf(0L) }
    val user by rflow(init = User()) { Repo.me() }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) { if (Build.VERSION.SDK_INT >= 33) perm.launch(Manifest.permission.POST_NOTIFICATIONS) }

    LaunchedEffect(user.username, user.pushEnabled) {
        if (user.username.isNotBlank()) {
            try { val tk = FirebaseMessaging.getInstance().token.await(); Repo.db.child("users/${Repo.uid()}/fcmToken").setValue(tk) } catch (_: Exception) { }
            try { val fm = FirebaseMessaging.getInstance(); if (user.pushEnabled) fm.subscribeToTopic("all") else fm.unsubscribeFromTopic("all") } catch (_: Exception) { }
        }
    }
    // Back: other tab -> Play, Play -> press twice to exit
    BackHandler {
        if (pager.currentPage != 1) scope.launch { pager.animateScrollToPage(1) }
        else {
            val now = System.currentTimeMillis()
            if (now - lastBack < 2000) (ctx as? Activity)?.finish() else { lastBack = now; ctx.toast(tx("Press back again to exit")) }
        }
    }
    Column(Modifier.fillMaxSize().background(BgBrush).statusBarsPadding()) {
        Box(Modifier.weight(1f)) {
            if (user.banned) { Column { HeaderBar(nav, user, earnTab = false); Text(tx("Your account is banned."), Modifier.padding(20.dp), color = Red) } }
            else {
                // The banner slider is a pager of its own: a swipe on its first banner (to the right) or on its last banner (to the left) is handed over to this tab pager.
                HorizontalPager(pager, Modifier.fillMaxSize(), beyondBoundsPageCount = 0, verticalAlignment = Alignment.Top) { page ->
                    // The header is part of every page, so the WHOLE page (header + content) slides together when swiping between tabs.
                    Column(Modifier.fillMaxSize()) {
                        HeaderBar(nav, user, earnTab = page == 0)
                        Box(Modifier.weight(1f)) {
                            when (page) {
                                0 -> EarnTab(nav)
                                1 -> HomeTab(nav)
                                else -> AccountTab(nav, user)
                            }
                        }
                    }
                }
            }
        }
        // Docked bar in EVERY theme (also Clear Glass): it touches the left, right and bottom edges and never covers the page.
        BottomBar(pager.currentPage) { i -> scope.launch { pager.animateScrollToPage(i) } }
    }
    if (user.banned) BannedDialog(nav, user.banReason)
    else NotifyPermissionGate()   // card "Allow notification" while notifications are off; goes away by itself once they are on
}

/**
 * Home banner slider (IMPORTANT + bottom banner), like the reference video (v2.56: a plain, finite Compose HorizontalPager):
 *  - banner inset 15 dp with rounded corners (8 dp); a ~5 dp piece of the previous / next banner shows beside it (pageSpacing 10 dp)
 *  - the user can swipe between the banners; the pager snaps and flings by itself
 *  - on its own: a new banner every 2.0 s, right -> left (0.22 s); after the LAST banner it restarts at the FIRST (slides back, as in the video)
 *  - FIRST banner + swipe to the right  -> the outer Earn / Play / Account pager takes the swipe (Earn opens from the left)
 *    LAST banner  + swipe to the left   -> the outer pager takes the swipe (Account opens from the right)
 *    (that is Compose's normal nested-scroll hand-over: a pager that cannot move further passes the rest of the swipe on)
 *  - the position is kept (saveable pager state) when the Home page is left and opened again
 *  - the page count is the real banner count (small), so nothing heavy sits inside the Home list
 *  - place it FULL WIDTH (no horizontal padding around it).
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun BannerPager(list: List<Banner>, nav: NavController, height: Int = 0) {
    val latest by rememberUpdatedState(list)
    val state = rememberPagerState(initialPage = 0, pageCount = { latest.size })
    if (list.isEmpty()) return
    val open = linkOpener(nav)
    val ctx = LocalContext.current
    val density = androidx.compose.ui.platform.LocalDensity.current
    val n = list.size
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val pageW = maxWidth - 30.dp
        val boxH = if (height > 0) height.dp else pageW / 2.2f
        val wPx = with(density) { pageW.roundToPx() }
        val hPx = with(density) { boxH.roundToPx() }
        // Load every banner into memory in advance, so a banner is already there when it slides in (no blank / flash).
        LaunchedEffect(list.map { it.image }, wPx, hPx) {
            if (wPx <= 0 || hPx <= 0) return@LaunchedEffect
            try {
                val loader = coil.Coil.imageLoader(ctx)
                list.forEach { b ->
                    if (b.image.isNotBlank()) loader.enqueue(coil.request.ImageRequest.Builder(ctx).data(b.image).size(wPx, hPx).scale(coil.size.Scale.FILL).build())
                }
            } catch (_: Exception) { }
        }
        // Automatic slide. A swipe by the user interrupts a running slide: that makes the slide call throw a CancellationException INTO this loop - it is
        // caught here (only a real cancellation of the loop is passed on), otherwise the loop would end silently and the slider would stop for good.
        LaunchedEffect(state, n) {
            if (n < 2) return@LaunchedEffect
            while (true) {
                delay(2000)
                if (state.isScrollInProgress) continue                       // the user is swiping / the banner is still settling
                val count = latest.size
                if (count < 2) continue
                val next = (state.currentPage + 1) % count
                try {
                    val info = state.layoutInfo
                    val unit = (info.pageSize + info.pageSpacing).toFloat()
                    if (unit > 0f) {
                        val delta = (next - state.currentPage) * unit - state.currentPageOffsetFraction * unit
                        state.animateScrollBy(delta, androidx.compose.animation.core.tween(if (next == 0) 450 else 220, easing = androidx.compose.animation.core.FastOutSlowInEasing))
                        // make sure it rests exactly on the page (never half-way)
                        if (state.currentPage != next || kotlin.math.abs(state.currentPageOffsetFraction) > 0.001f) state.scrollToPage(next)
                    }
                } catch (e: kotlinx.coroutines.CancellationException) {
                    if (kotlin.coroutines.coroutineContext[kotlinx.coroutines.Job]?.isActive == false) throw e
                } catch (_: Exception) { }
            }
        }
        HorizontalPager(state, Modifier.fillMaxWidth(), contentPadding = PaddingValues(horizontal = 15.dp), pageSpacing = 10.dp, beyondBoundsPageCount = 1) { page ->
            val item = latest.getOrNull(page)
            if (item != null) {
                AsyncImage(item.image, null,
                    Modifier.fillMaxWidth().then(if (height > 0) Modifier.height(height.dp) else Modifier.aspectRatio(2.2f))
                        .clip(RoundedCornerShape(8.dp)).clickable { open(item.link) },
                    contentScale = ContentScale.Crop)
            }
        }
    }
}

/** Compact bar under the header: shows the TITLE of the latest announcement (no scrolling). Tap = Announcements page. Look is FIXED (admin cannot change it). */
@Composable
fun AnnouncementTicker(nav: NavController) {
    val list by rflow(init = emptyList<Ann>()) { Repo.announcements() }
    val a = list.firstOrNull() ?: return
    val line = brandAppName(a.heading())
    Row(Modifier.fillMaxWidth().heightIn(min = 36.dp).clip(RoundedCornerShape(14.dp)).background(glassOr(Color(0xFF1B0238)))
        .clickable { nav.go("announcements") }
        .padding(start = 12.dp, end = 12.dp, top = 5.dp, bottom = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Image(painterResource(R.drawable.ic_megaphone_rf), null, Modifier.size(26.dp)); Spacer(Modifier.width(14.dp))
        Text(line, Modifier.weight(1f), maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis, fontSize = 14.sp,
            fontWeight = FontWeight.Medium, letterSpacing = 0.4.sp, color = Color.White)
    }
}

/** Support / WhatsApp / YouTube / My Wallet shortcuts. The WhatsApp and YouTube links are set in the admin app (Settings). */
@Composable
fun QuickActions(nav: NavController) {
    val ctx = LocalContext.current
    val waHome by rflow(init = "") { Repo.setting("homeWhatsappUrl") }
    val waEarn by rflow(init = "") { Repo.setting("whatsappUrl") }
    val yt by rflow(init = "") { Repo.setting("homeYoutubeUrl") }
    fun open(url: String) {
        if (url.isBlank()) { ctx.toast(tx("Link not added yet")); return }
        try { ctx.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url.trim())).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { ctx.toast(tx("Link not added yet")) }
    }
    @Composable
    fun Item(label: String, icon: @Composable () -> Unit, onClick: () -> Unit) {
        Column(Modifier.width(76.dp).bounceClick(onClick = onClick), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(68.dp).clip(RoundedCornerShape(20.dp)).background(ButtonC), contentAlignment = Alignment.Center) { icon() }
            Text(label, Modifier.padding(top = 8.dp), fontSize = 14.sp, maxLines = 1, textAlign = TextAlign.Center)
        }
    }
    Row(Modifier.fillMaxWidth().padding(top = 20.dp, bottom = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Item(tx("Support"), { Icon(Icons.Default.Headset, null, Modifier.size(34.dp), tint = OnButton) }) { nav.go("support") }
        Item("WhatsApp", { Icon(androidx.compose.ui.res.painterResource(R.drawable.ic_whatsapp), null, Modifier.size(34.dp), tint = OnButton) }) { open(waHome.ifBlank { waEarn }) }
        Item("YouTube", { Icon(androidx.compose.ui.res.painterResource(R.drawable.ic_youtube), null, Modifier.size(36.dp), tint = OnButton) }) { open(yt) }
        Item(tx("My Wallet"), { Icon(Icons.Default.AccountBalanceWallet, null, Modifier.size(34.dp), tint = walletIconC(ButtonC)) }) { nav.go("wallet") }
    }
}

@Composable
private fun SocialDot(brush: androidx.compose.ui.graphics.Brush, icon: Int, onClick: () -> Unit) {
    Box(Modifier.size(30.dp).clip(CircleShape).background(brush).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(androidx.compose.ui.res.painterResource(icon), null, Modifier.size(18.dp), tint = Color.White)
    }
}

/** Fixed "Refer And Earn" picture card between "My contests" and the share buttons. Not clickable, not controlled from Admin. */
@Composable
fun HomeInfoCard() {
    Box(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 14.dp)) {
        Image(painterResource(R.drawable.home_card), null, Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)), contentScale = ContentScale.FillWidth)
    }
}

/** Share buttons under "My contests". All 5 SHARE THE APP (they never open admin links). */
@Composable
fun ShareSection() {
    val ctx = LocalContext.current
    val shareText by rflow(init = "") { Repo.setting("shareText") }
    val text = brandAppName(shareText.ifBlank { tx("BESTWIN ESPORTS Platform\nPlay Daily Matches & Win Big Prizes.") })
    Column(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        // Slim 30 dp high buttons (as in the reference): each is only as wide as its content, the round icons below are 30 dp too.
        Row(horizontalArrangement = Arrangement.spacedBy(11.dp), verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.height(30.dp).clip(RoundedCornerShape(3.dp)).background(glassOr(Color(0xFF180036))).clickable { shareApp(ctx, text) }.padding(horizontal = 17.dp),
                horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Share, null, Modifier.size(15.dp), tint = Color.White); Spacer(Modifier.width(10.dp))
                Text(tx("Share"), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White, maxLines = 1)
            }
            Row(Modifier.height(30.dp).clip(RoundedCornerShape(3.dp)).background(Color(0xFF01A15F)).clickable { shareApp(ctx, text, "com.whatsapp", "com.whatsapp.w4b") }.padding(horizontal = 17.dp),
                horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                Icon(androidx.compose.ui.res.painterResource(R.drawable.ic_whatsapp), null, Modifier.size(15.dp), tint = Color.White); Spacer(Modifier.width(10.dp))
                Text(tx("Share on Whatsapp"), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(15.dp)) {
            SocialDot(androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color(0xFFFEDA75), Color(0xFFFA7E1E), Color(0xFFD62976), Color(0xFF962FBF), Color(0xFF4F5BD5))), R.drawable.ic_instagram) { shareApp(ctx, text, "com.instagram.android") }
            SocialDot(androidx.compose.ui.graphics.SolidColor(Color(0xFF229ED9)), R.drawable.ic_telegram) { shareApp(ctx, text, "org.telegram.messenger", "org.telegram.messenger.web", "org.thunderdog.challegram") }
            SocialDot(androidx.compose.ui.graphics.SolidColor(Color(0xFF25D366)), R.drawable.ic_whatsapp) { shareApp(ctx, text, "com.whatsapp", "com.whatsapp.w4b") }
        }
    }
}

@Composable
fun HomeTab(nav: NavController) {
    var rev by remember { mutableIntStateOf(0) }
    val important by rflowKeep(rev, init = emptyList<Banner>()) { Repo.banners("important") }
    val welcome by rflowKeep(rev, init = emptyList<Banner>()) { Repo.banners("welcome") }
    val ff by rflowKeep(rev, init = "") { Repo.setting("ffImage") }
    val pv by rflowKeep(rev, init = "") { Repo.setting("privateImage") }
    val quickOn by rflowKeep(rev, init = "") { Repo.setting("homeQuickOn") }
    val secsDb by rflowKeep(rev, init = emptyList<Section>()) { Repo.sections() }
    val secs = secsDb.ifEmpty { listOf(Section("freefire", "FREE FIRE", ff, "games", 1), Section("private", "PRIVATE", pv, "player", 2)) }
    Column(Modifier.fillMaxSize()) {
        Box(Modifier.padding(horizontal = 14.dp, vertical = 4.dp)) { AnnouncementTicker(nav) }
        PullRefresh({ rev++ }, Modifier.weight(1f).fillMaxWidth()) {
            // Lazy rendering keeps off-screen banners/images and their auto-slide coroutines inactive until they are near view.
            LazyColumn(Modifier.fillMaxSize()) {
                item(key = "home-voice") { HomeVoiceCard() }   // right under the announcement bar, scrolls up with the page
                item(key = "home-important-title") {
                    Column(Modifier.padding(horizontal = 14.dp)) { SectionTitle(tx("IMPORTANT"), tx("Updates and Alerts"), icon = "info") }
                }
                item(key = "home-important-banners") { BannerPager(important, nav) }
                if (quickOn.trim().equals("true", ignoreCase = true)) item(key = "home-quick-actions") {
                    Column(Modifier.padding(horizontal = 14.dp)) { QuickActions(nav) }
                }
                item(key = "home-exclusive-title") {
                    Column(Modifier.padding(horizontal = 14.dp)) {
                        SectionTitle(tx("EXCLUSIVE"), tx("Big Winnings For All"), icon = "box")
                        Spacer(Modifier.height(10.dp))
                    }
                }
                // Sections come from Admin -> Sections (default: FREE FIRE and PRIVATE). Only visible rows are composed.
                secs.chunked(2).forEachIndexed { ri, rowSecs ->
                    item(key = "home-section-row-$ri") {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp).padding(top = if (ri > 0) 20.dp else 0.dp), horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                            rowSecs.forEach { sec ->
                                val name = tx(sec.name)
                                Box(Modifier.weight(1f).aspectRatio(1.02f).bounceClick { nav.go(if (sec.type == "player") "pvp" else "games/${sec.id}") }) {
                                    Box(Modifier.fillMaxSize().clip(RoundedCornerShape(24.dp))) {
                                        AsyncImage(sec.image, name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                                        Box(Modifier.align(Alignment.BottomEnd).padding(end = 8.dp, bottom = 8.dp).clip(RoundedCornerShape(20.dp)).background(Color.White).padding(horizontal = 14.dp, vertical = 6.dp)) {
                                            Text(tx("PLAY") + " \u25B8", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        }
                                    }
                                    Row(Modifier.align(Alignment.TopStart).offset(x = (-4).dp, y = (-12).dp).clip(RoundedCornerShape(50))
                                        .background(androidx.compose.ui.graphics.Brush.horizontalGradient(listOf(Color(0xFF000731), Color(0xFF0022E0))))
                                        .padding(start = 10.dp, end = 14.dp, top = 5.dp, bottom = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Shield, null, tint = Color(0xFF00E676), modifier = Modifier.size(20.dp))
                                        Spacer(Modifier.width(6.dp)); Text(tx("FairPlay : ON"), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                    }
                                }
                            }
                            if (rowSecs.size < 2) Spacer(Modifier.weight(1f))
                        }
                    }
                }
                item(key = "home-contests") {
                    Column(Modifier.padding(horizontal = 14.dp)) {
                        SectionTitle(tx("MY CONTESTS"), tx("Your Tournaments Journey"), icon = "check")
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                            listOf(Triple(tx("Ongoing"), R.drawable.ic_home_ongoing, "ongoing"), Triple(tx("Upcoming"), R.drawable.ic_home_upcoming, "upcoming"),
                                Triple(tx("Completed"), R.drawable.ic_home_completed, "completed")).forEach { (t, ic, k) ->
                                Column(Modifier.weight(1f).height(115.dp).clip(RoundedCornerShape(6.dp)).background(HomeBoxC).clickable { nav.go("mymatches/$k") },
                                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                    Icon(painterResource(ic), null, tint = HomeRed, modifier = Modifier.size(62.dp)); Spacer(Modifier.height(4.dp))
                                    Text(t, fontSize = 19.sp, color = Color.White)
                                }
                            }
                        }
                    }
                }
                item(key = "home-info-card") { Column(Modifier.padding(horizontal = 14.dp)) { HomeInfoCard() } }
                item(key = "home-share") {
                    Column(Modifier.padding(horizontal = 14.dp)) { ShareSection(); Spacer(Modifier.height(16.dp)) }
                }
                item(key = "home-welcome-banners") { BannerPager(welcome, nav, 140) }
                item(key = "home-footer") { Column { Spacer(Modifier.height(16.dp)); ClearBarSpacer() } }
            }
        }
    }
}

/** Earn tab: big banners (image + link) added by the admin in Admin -> Banners -> "Earn tab". */
@Composable
fun EarnTab(nav: NavController) {
    val list by rflow(init = emptyList<Banner>()) { Repo.banners("earn") }
    val open = linkOpener(nav)
    // HorizontalPager centres every page vertically by default (verticalAlignment = CenterVertically), which pushed a single banner to the middle.
    // The pager now uses Alignment.Top, and the Earn page is also forced to fill the whole page and start at the top.
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(14.dp, Alignment.Top)) {
        if (list.isEmpty()) Text(tx("No offers yet"), Modifier.fillMaxWidth().padding(40.dp), textAlign = TextAlign.Center, color = Color.Gray)
        list.forEach { b ->
            AsyncImage(b.image, null, Modifier.fillMaxWidth().aspectRatio(2.08f).clip(RoundedCornerShape(12.dp)).clickable { open(b.link) }, contentScale = ContentScale.Crop)
        }
        Spacer(Modifier.height(8.dp))
        ClearBarSpacer()
    }
}

/**
 * OLD "My Wallet" design (admin: Settings -> "My Wallet page design" = Old). Black page + black top bar, big rounded card with the five
 * balances on the left, ADD COINS (blue) and REDEEM COINS (amber) on the right, WALLET HISTORY link under the card.
 * Sizes / colours were measured from the reference screenshot and are fixed (they do not change with the theme).
 */
private val OldWalletLabel = Color(0xFF757575)
private val OldWalletAdd = Color(0xFF3C0BA2)
private val OldWalletRedeem = Color(0xFFF7AF05)

@Composable
private fun OldWalletBlock(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxHeight()) {
        Text(label, color = OldWalletLabel, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        Spacer(Modifier.height(4.dp))
        Text(value, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
private fun OldWalletButton(text: String, bg: Color, modifier: Modifier, onClick: () -> Unit) {
    Box(modifier.width(180.dp).height(38.dp).clip(RoundedCornerShape(12.dp)).background(bg).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Text(text, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
fun OldWalletPage(nav: NavController, u: User, tour: WalletTourState? = null) {
    val coins = tx("Coins")
    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, null, Modifier.size(24.dp).clickable { nav.back() }, tint = Color.White)
            Spacer(Modifier.width(8.dp))
            Text(tx("My Wallet"), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            Column(Modifier.fillMaxWidth().padding(start = 24.dp, end = 24.dp, top = 24.dp).clip(RoundedCornerShape(18.dp)).background(AccountC)
                .padding(start = 16.dp, end = 16.dp, top = 27.dp, bottom = 21.dp)) {
                OldWalletBlock(tx("TOTAL BALANCE"), "${fmt(u.balance())} $coins", Modifier.height(50.dp))
                Row(Modifier.fillMaxWidth().height(50.dp), verticalAlignment = Alignment.CenterVertically) {
                    OldWalletBlock(tx("Deposited"), "${fmt(u.deposited)} $coins", Modifier.weight(1f))
                    OldWalletButton(tx("ADD COINS"), OldWalletAdd, Modifier.onGloballyPositioned { tour?.add = it.boundsInWindow() }) { nav.go("addmoney") }
                }
                Row(Modifier.fillMaxWidth().height(50.dp), verticalAlignment = Alignment.CenterVertically) {
                    OldWalletBlock(tx("Winning"), "${fmt(u.winning)} $coins", Modifier.weight(1f))
                    OldWalletButton(tx("REDEEM COINS"), OldWalletRedeem, Modifier.onGloballyPositioned { tour?.withdraw = it.boundsInWindow() }) { nav.go("withdraw") }
                }
                OldWalletBlock(tx("Earnings"), "${fmt(u.earnings)} $coins", Modifier.height(50.dp))
                OldWalletBlock(tx("PAYOUTS"), "${money(u.payouts)} $coins", Modifier.height(50.dp))
            }
            Box(Modifier.fillMaxWidth().clickable { nav.go("history") }.padding(vertical = 20.dp), contentAlignment = Alignment.Center) {
                Text(tx("WALLET HISTORY"), color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
fun WalletTab(nav: NavController, u: User, tour: WalletTourState? = null) {
    val walletNote by rflow(init = "") { Repo.setting("walletNote") }
    Column(Modifier.verticalScroll(rememberScrollState())) {
        Column(Modifier.padding(14.dp).clip(RoundedCornerShape(14.dp)).background(AccountC).slateEdge(RoundedCornerShape(14.dp)).padding(16.dp)) {
            WRow(tx("Total Balance"), fmt(u.balance()), tx("History"), Color.Black) { nav.go("history") }   // fixed black in every theme
            HorizontalDivider(Modifier.padding(vertical = 12.dp), color = Color.Gray)
            WRow(tx("Deposited"), fmt(u.deposited), tx("Add Coins"), Purple, Modifier.onGloballyPositioned { tour?.add = it.boundsInWindow() }, whiteContent = true) { nav.go("addmoney") }
            HorizontalDivider(Modifier.padding(vertical = 12.dp), color = Color.Gray)
            WRow(tx("Winning"), fmt(u.winning), tx("Withdraw"), Purple, Modifier.onGloballyPositioned { tour?.withdraw = it.boundsInWindow() }, whiteContent = true) { nav.go("withdraw") }
            HorizontalDivider(Modifier.padding(vertical = 12.dp), color = Color.Gray)
            Text(tx("Earnings"), color = Color.Gray, fontSize = 14.sp); Text(money(u.earnings), fontSize = 20.sp, fontWeight = FontWeight.Medium)
            HorizontalDivider(Modifier.padding(vertical = 12.dp), color = Color.Gray)
            Text(tx("Payouts"), color = Color.Gray, fontSize = 14.sp); Text(money(u.payouts), fontSize = 20.sp, fontWeight = FontWeight.Medium)
            Text(tx("Only winnings can be redeemed."), Modifier.fillMaxWidth().padding(top = 18.dp), textAlign = TextAlign.Center, fontSize = 12.sp)
            Text(tx(walletNote.ifBlank { "Fast Withdrawals, Processed Within 24 Hours!" }), Modifier.fillMaxWidth().padding(top = 4.dp), textAlign = TextAlign.Center, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
/** Text + icon colour that is always WHITE, and only turns black when the button colour itself is (almost) white. */
private fun whiteUnlessWhiteBg(bg: Color): Color {
    if (bg.alpha < 0.9f) return Color.White
    fun lin(c: Float) = if (c <= 0.03928f) c / 12.92f else Math.pow(((c + 0.055f) / 1.055f).toDouble(), 2.4).toFloat()
    val l = 0.2126f * lin(bg.red) + 0.7152f * lin(bg.green) + 0.0722f * lin(bg.blue)
    return if (l > 0.85f) Color.Black else Color.White
}

@Composable
fun WRow(label: String, value: String, btn: String, color: Color, btnModifier: Modifier = Modifier, whiteContent: Boolean = false, onClick: () -> Unit) {
    val fg = if (whiteContent) whiteUnlessWhiteBg(color) else onC(color)
    val fgIcon = if (whiteContent) fg else walletIconC(color)
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(label, color = Color.Gray, fontSize = 14.sp); Text(value, fontSize = 22.sp, fontWeight = FontWeight.Medium) }
        Row(btnModifier.width(128.dp).height(36.dp).clip(RoundedCornerShape(6.dp)).background(color).clickable(onClick = onClick),
            horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.AccountBalanceWallet, null, Modifier.size(16.dp), tint = fgIcon); Spacer(Modifier.width(6.dp)); Text(btn, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = fg)
        }
    }
}

@Suppress("DEPRECATION")
@Composable
fun AccountTab(nav: NavController, u: User) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val logo by rflow(init = "") { Repo.setting("logoUrl") }
    val shareText by rflow(init = "") { Repo.setting("shareText") }
    val spinCfg by rflow(init = SpinCfg()) { SpinRepo.config() }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Column(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(92.dp).padding(3.dp)) { ProfileLogo(logo, 86) }
            Spacer(Modifier.height(8.dp))
            Text(u.username, fontSize = 18.sp, fontWeight = FontWeight.Medium)
            Text(if (u.kyc) tr("kyc_verified") else tr("kyc_pending"), color = if (u.kyc) SuccessC else Orange, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
        Row(Modifier.padding(14.dp).fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(AccountC).slateEdge(RoundedCornerShape(8.dp)).padding(vertical = 14.dp)) {
            Stat("${u.matchesPlayed}", tr("matches_played"), Modifier.weight(1f)); VerticalDivider(Modifier.height(50.dp), color = Color.White)
            Stat("${u.kills}", tr("total_kills"), Modifier.weight(1f)); VerticalDivider(Modifier.height(50.dp), color = Color.White)
            Stat(money(u.earnings), tr("amount_won"), Modifier.weight(1f), coin = true)
        }
        MenuRow(Icons.Default.Notifications, tr("push_notifications"), trailing = {
            Switch(u.pushEnabled, { scope.launch { Repo.setPush(it) } }, Modifier.height(24.dp))
        }) { scope.launch { Repo.setPush(!u.pushEnabled) } }
        MenuRow(Icons.Default.AccountCircle, tr("my_profile")) { nav.go("profile") }
        MenuRow(Icons.Default.AccountBalanceWallet, tr("my_wallet")) { nav.go("wallet") }
        MenuRow(Icons.Default.SportsEsports, tr("my_matches")) { nav.go("mymatches/upcoming") }
        MenuRow(Icons.Default.BarChart, tr("statistics")) { nav.go("stats") }
        MenuRow(Icons.Default.CardGiftcard, tr("rewards")) { nav.go("rewards") }
        val freeSpins by rflow(init = 0) { SpinRepo.bonus() }
        if (spinCfg.enabled) MenuRow(Icons.Default.Casino, tx("Lucky Wheel") + (if (freeSpins > 0) "  ($freeSpins " + tx("free") + ")" else "")) { nav.go("spin") }
        MenuRow(Icons.Default.Group, tr("referrals")) { nav.go("referrals") }
        MenuRow(Icons.Default.Flag, tr("announcements")) { nav.go("announcements") }
        VoicePrefs.load(ctx)
        val voiceInbox by rflow(init = emptyList<VoiceMsg>()) { VoiceRepo.inbox() }
        val unheardVoice = voiceInbox.count { it.ts > VoicePrefs.lastSeen }
        MenuRow(Icons.Default.Mic, tx("Voice messages"), trailing = {
            if (unheardVoice > 0) Box(Modifier.clip(RoundedCornerShape(10.dp)).background(Red).padding(horizontal = 8.dp, vertical = 2.dp)) { Text("$unheardVoice", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White) }
            else Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, Modifier.size(20.dp))
        }) { nav.go("voicemessages") }
        MenuRow(Icons.Default.Star, tx("Top Players")) { nav.go("leaderboard") }
        MenuRow(Icons.Default.Leaderboard, tx("Leaderboard")) { nav.go("refboard") }
        MenuRow(Icons.Default.Help, tr("tutorial")) { nav.go("tutorial") }
        MenuRow(Icons.Default.Info, tr("about")) { nav.go("info/about/About us") }
        MenuRow(Icons.Default.Headset, tr("customer_support")) { nav.go("support") }
        MenuRow(Icons.Default.Share, tr("share_app")) {
            val t = brandAppName(shareText.ifBlank { tx("BESTWIN ESPORTS Platform\nPlay Daily Matches & Win Big Prizes.") })
            shareApp(ctx, t)
        }
        MenuRow(Icons.Default.Description, tr("terms")) { nav.go("info/terms/Terms and Conditions") }
        MenuRow(Icons.Outlined.Language, tr("change_language")) { nav.go("lang") }
        MenuRow(Icons.Default.PowerSettingsNew, tr("logout")) { Repo.auth.signOut(); ctx.toast(tx("Log out Successfully")); nav.navigate("login") { popUpTo(0) } }
        Text("Version : ${appVersionName(ctx)}", Modifier.fillMaxWidth().padding(top = 20.dp, start = 20.dp, end = 20.dp, bottom = 6.dp), textAlign = TextAlign.Center, fontSize = 13.sp)
        // Permanent developer credit: fixed text + fixed Telegram link (not controlled from the admin panel).
        Text("DEVELOPER CODE X", Modifier.fillMaxWidth().clickable { ctx.openLink("https://t.me/developercodex", nav = nav) }.padding(start = 20.dp, end = 20.dp, top = 6.dp, bottom = 24.dp),
            textAlign = TextAlign.Center, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Purple)
        ClearBarSpacer()
    }
}

@Composable
private fun Stat(v: String, label: String, modifier: Modifier, coin: Boolean = false) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Row(verticalAlignment = Alignment.CenterVertically) { if (coin) { CoinIcon(18); Spacer(Modifier.width(4.dp)) }; Text(v, fontSize = 18.sp, fontWeight = FontWeight.Medium) }
        Text(label, textAlign = TextAlign.Center, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}
