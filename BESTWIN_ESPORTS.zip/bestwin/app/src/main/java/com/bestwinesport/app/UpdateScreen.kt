package com.bestwinesport.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Downloads the new APK inside the app (with progress) and opens the Android installer. */
object UpdateDownloader {
    /** Turns Google Drive / Dropbox share links into direct download links. */
    fun directUrl(raw: String): String {
        val u = raw.trim()
        Regex("drive\\.google\\.com/file/d/([^/?#]+)").find(u)?.let { return "https://drive.google.com/uc?export=download&id=" + it.groupValues[1] }
        Regex("drive\\.google\\.com/open\\?id=([^&#]+)").find(u)?.let { return "https://drive.google.com/uc?export=download&id=" + it.groupValues[1] }
        if (u.contains("dropbox.com")) {
            return if (u.contains("dl=0")) u.replace("dl=0", "dl=1") else if (u.contains("dl=1")) u else if (u.contains("?")) "$u&dl=1" else "$u?dl=1"
        }
        return u
    }

    suspend fun download(ctx: Context, link: String, onProgress: (Int) -> Unit): File = withContext(Dispatchers.IO) {
        val dir = File(ctx.cacheDir, "updates").apply { mkdirs(); listFiles()?.forEach { it.delete() } }
        val out = File(dir, "update.apk")
        var url = link
        var conn: HttpURLConnection? = null
        try {
            var hops = 0
            while (true) {
                val c = URL(url).openConnection() as HttpURLConnection
                c.instanceFollowRedirects = false; c.connectTimeout = 20000; c.readTimeout = 30000
                c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) BESTWIN ESPORTS")
                val code = c.responseCode
                if (code in 300..399 && hops < 6) {
                    val next = c.getHeaderField("Location") ?: throw IOException("redirect")
                    url = URL(URL(url), next).toString(); hops++; c.disconnect(); continue
                }
                if (code !in 200..299) { c.disconnect(); throw IOException("HTTP $code") }
                conn = c; break
            }
            val c = conn!!
            if ((c.contentType ?: "").lowercase().startsWith("text/html")) throw IOException("not_apk")
            val total = c.contentLengthLong
            var done = 0L; var last = -1
            c.inputStream.use { input -> out.outputStream().use { o ->
                val buf = ByteArray(32 * 1024)
                while (true) {
                    val n = input.read(buf); if (n < 0) break
                    o.write(buf, 0, n); done += n
                    if (total > 0) { val p = (done * 100 / total).toInt().coerceIn(0, 100); if (p != last) { last = p; onProgress(p) } }
                }
            } }
            if (out.length() < 200_000) throw IOException("not_apk")
            onProgress(100)
            out
        } finally { conn?.disconnect() }
    }

    /** returns false when Android first needs the "Install unknown apps" permission (the settings page is opened). */
    fun install(ctx: Context, f: File): Boolean {
        if (Build.VERSION.SDK_INT >= 26 && !ctx.packageManager.canRequestPackageInstalls()) {
            ctx.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return false
        }
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
        ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    }
}

/**
 * Full-screen "App Update" page. The admin sets the version, the notes and the APK link in Admin -> App control.
 * Tapping Update Now downloads the file here (progress bar) and opens the installer. forced = no way to skip.
 */
@Composable
fun UpdateScreen(cfg: AppConfig, forced: Boolean, onLater: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var progress by remember { mutableIntStateOf(0) }
    var phase by remember { mutableStateOf("idle") }          // idle / downloading / ready / error
    var file by remember { mutableStateOf<File?>(null) }
    var error by remember { mutableStateOf("") }
    fun start() {
        if (cfg.updateUrl.isBlank()) { ctx.toast(tx("Please update the app from the store")); return }
        phase = "downloading"; progress = 0; error = ""
        scope.launch {
            try {
                val f = UpdateDownloader.download(ctx, UpdateDownloader.directUrl(cfg.updateUrl)) { p -> progress = p }
                file = f; phase = "ready"
                UpdateDownloader.install(ctx, f)
            } catch (e: kotlinx.coroutines.CancellationException) { throw e }
            catch (e: Exception) {
                phase = "error"
                if (e.message == "not_apk") { error = tx("This link is not a direct APK download. Opening it in the browser."); ctx.openLink(cfg.updateUrl) }
                else error = tx("Download failed. Tap to retry")
            }
        }
    }
    Column(Modifier.fillMaxSize().background(BgBrush)) {
        Box(Modifier.fillMaxWidth().background(BarC).statusBarsPadding().padding(vertical = 12.dp)) {
            if (!forced) Icon(Icons.AutoMirrored.Filled.ArrowBack, null, Modifier.padding(start = 14.dp).size(22.dp).clickable { onLater() }.align(Alignment.CenterStart))
            Text(tx("App Update"), Modifier.fillMaxWidth(), fontSize = 17.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(20.dp))
            Image(painterResource(R.drawable.bestwin_logo), null, Modifier.size(84.dp).clip(RoundedCornerShape(8.dp)), contentScale = ContentScale.Crop)
            Spacer(Modifier.height(10.dp))
            Text("BESTWIN ESPORTS" + if (cfg.latestName.isNotBlank()) "  v${cfg.latestName}" else "", fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(18.dp))
            if (phase == "downloading" || phase == "ready") {
                Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(Field)) {
                    Box(Modifier.fillMaxWidth(progress / 100f).fillMaxHeight().background(Purple))
                }
                Row(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                    Text(if (phase == "ready") tx("Downloaded") else tx("Downloading..."), Modifier.weight(1f), fontSize = 13.sp)
                    Text("$progress/100", fontSize = 13.sp)
                }
                Spacer(Modifier.height(14.dp))
            }
            if (error.isNotBlank()) { Text(error, color = Purple, fontSize = 14.sp, modifier = Modifier.padding(bottom = 16.dp)) }
            val notes = cfg.updateNotes.ifBlank { tx("A newer version of the app is ready.") }
            Text(brandAppName(notes), Modifier.fillMaxWidth(), fontSize = 14.sp, lineHeight = 22.sp)
            Spacer(Modifier.height(24.dp))
        }
        if (!forced) Text(tx("Later"), Modifier.fillMaxWidth().clickable { onLater() }.padding(vertical = 10.dp), color = Color.Gray, textAlign = TextAlign.Center, fontSize = 15.sp)
        Box(Modifier.fillMaxWidth().background(ButtonC).clickable(enabled = phase != "downloading") {
            val f = file
            if (phase == "ready" && f != null) { UpdateDownloader.install(ctx, f) } else start()
        }.navigationBarsPadding().padding(vertical = 13.dp), contentAlignment = Alignment.Center) {
            Text(when (phase) { "downloading" -> tx("Downloading..."); "ready" -> tx("Install Now"); "error" -> tx("Try again"); else -> tx("Update Now") },
                color = OnButton, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
    }
}
