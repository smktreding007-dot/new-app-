package com.bestwinesport.app

import android.content.Context
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateRectAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

/** Window positions of the two wallet buttons (filled by WalletTab) - the spotlight (rounded rectangle, same shape as the button) is drawn around them. */
class WalletTourState {
    var add by mutableStateOf<Rect?>(null)
    var withdraw by mutableStateOf<Rect?>(null)
}

/**
 * First-time guide on the wallet page: the screen dims, a rounded-rectangle spotlight (no circle) shows the ADD COINS button with
 * "Tap here to add points in wallet"; a tap moves the spotlight to the withdraw button with
 * "Tap here to withdraw points from wallet"; the next tap closes the guide. Shown only ONCE per install.
 */
@Composable
fun WalletTour(tour: WalletTourState) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("wallet_tour", Context.MODE_PRIVATE) }
    var done by remember { mutableStateOf(prefs.getBoolean("done", false)) }
    if (done) return
    var step by remember { mutableIntStateOf(0) }
    var origin by remember { mutableStateOf(Offset.Zero) }
    var originSet by remember { mutableStateOf(false) }
    val fade = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val target = if (step == 0) tour.add else tour.withdraw
    val ready = originSet && tour.add != null && tour.withdraw != null
    LaunchedEffect(ready) { if (ready) fade.animateTo(1f, tween(350)) }
    // The spotlight is the BUTTON's own rectangle (+ a little padding), not a big circle, so it never covers / cuts the neighbouring button.
    val box by animateRectAsState((target ?: Rect.Zero).translate(-origin.x, -origin.y), tween(400), label = "tourRect")

    Box(Modifier.fillMaxSize()
        .onGloballyPositioned { origin = it.positionInWindow(); originSet = true }
        .pointerInput(ready) {
            detectTapGestures {
                if (!ready) return@detectTapGestures
                if (step == 0) step = 1
                else scope.launch {
                    fade.animateTo(0f, tween(300))
                    prefs.edit().putBoolean("done", true).apply()
                    done = true
                }
            }
        }) {
        if (ready) {
            Canvas(Modifier.fillMaxSize().graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)) {
                drawRect(Color.Black.copy(alpha = 0.9f * fade.value))
                // Round spotlight centred on the button (like the screenshot), NO outline / ring - nothing here follows the theme.
                val centre = Offset(box.center.x, box.center.y)
                val radius = box.width / 2f + 8.dp.toPx()
                drawCircle(Color.Black, radius = radius, center = centre, blendMode = BlendMode.Clear)
            }
            Column(Modifier.fillMaxSize()) {
                Spacer(Modifier.fillMaxHeight(0.63f))
                Box(Modifier.fillMaxWidth().padding(horizontal = 10.dp), contentAlignment = Alignment.TopCenter) {
                    Text(
                        tx(if (step == 0) "Tap here to add points in wallet" else "Tap here to withdraw points from wallet"),
                        color = Color.White.copy(alpha = fade.value), fontSize = 19.sp, fontWeight = FontWeight.Bold, lineHeight = 25.sp
                    )
                }
            }
        }
    }
}
