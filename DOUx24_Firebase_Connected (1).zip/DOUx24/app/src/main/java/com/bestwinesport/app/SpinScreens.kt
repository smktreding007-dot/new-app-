package com.bestwinesport.app

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.navigation.NavController
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

// ---------------------------------------------------------------------------------------------------------------
// Lucky Wheel (Spin). The admin controls everything (Admin app -> Lucky Wheel). The reward is picked and added to the
// wallet by the app inside ONE atomic Firebase write that the database rules check (no backend / Railway needed).
// ---------------------------------------------------------------------------------------------------------------

/** Admin switch + the games where the Lucky Wheel banner is shown (database: spinConfig). */
data class SpinCfg(val enabled: Boolean = false, val games: Set<String> = emptySet())

data class SpinStatus(
    val enabled: Boolean = false, val canSpin: Boolean = false, val reason: String = "", val message: String = "",
    val required: Int = 0, val available: Int = 0, val minEntryFee: Double = 0.0,
    val dailyLimit: Int = 0, val todayCount: Int = 0, val nextSpinAt: Long = 0L,
    val totalEarned: Double = 0.0, val totalSpins: Long = 0L, val bonus: Int = 0,
    val segments: List<Double> = emptyList(), val creditTo: String = "deposited"
)

class SpinResult(val amount: Double, val index: Int, val status: SpinStatus)
class SpinHist(val amount: Double, val ts: Long)
class SpinOutcome<T>(val value: T?, val error: String?)

/**
 * Lucky Wheel logic that runs inside the app + Firebase only (NO backend / Railway needed).
 * The database rules (database.rules.json -> spinState / users deposited / spinBonus / spinHistory) check every spin:
 * Lucky Wheel ON, player not blocked, reward not above the lock and the wheel's highest reward, daily limit, minimum days
 * between spins, admin free spins, and that the wallet goes up by exactly the reward - all in ONE atomic write.
 */
object SpinApi {
    private const val DAY_MS = 86_400_000L
    private const val IST_MS = 19_800_000L

    private class Cfg(
        val enabled: Boolean, val required: Int, val minFee: Double, val daily: Int, val cooldownDays: Double,
        val lockAll: Double, val creditTo: String, val countPast: Boolean, val amounts: List<Double>, val weights: List<Double>
    )

    private class St(
        val exists: Boolean, val consumed: Long, val dayStart: Long, val dayCount: Long,
        val totalSpins: Long, val totalEarned: Double, val lastNormalAt: Long
    )

    private class Ctx(val cfg: Cfg, val lock: Double, val blocked: Boolean, val bonus: Int, val st: St, val qualified: Int)
    private class Ev(val canSpin: Boolean, val reason: String, val useBonus: Boolean, val available: Int, val todayCount: Int, val nextSpinAt: Long)

    @Volatile private var offset: Long? = null
    @Volatile private var cached: Ctx? = null
    @Volatile private var cachedAt: Long = 0L

    private fun d(v: Any?, def: Double = 0.0): Double = (v as? Number)?.toDouble() ?: def

    private suspend fun <T> safe(block: suspend () -> T): T? = try {
        block()
    } catch (e: kotlinx.coroutines.CancellationException) {
        throw e
    } catch (e: Exception) {
        null
    }

    private fun parseCfg(s: DataSnapshot): Cfg {
        val amounts = ArrayList<Double>()
        val weights = ArrayList<Double>()
        for (c in s.child("segments").children) {
            val a = d(c.child("amount").value)
            val w = d(c.child("weight").value, 1.0)
            if (a > 0.0 && a <= 100000.0 && w >= 0.0 && amounts.size < 12) { amounts.add(a); weights.add(w) }
        }
        if (amounts.size < 2) {
            amounts.clear(); weights.clear()
            amounts.addAll(listOf(2.0, 5.0, 10.0, 25.0, 50.0, 100.0, 500.0, 1000.0))
            weights.addAll(listOf(30.0, 25.0, 18.0, 12.0, 8.0, 4.0, 2.0, 1.0))
        }
        return Cfg(
            enabled = s.child("enabled").value == true,
            required = d(s.child("matchesRequired").value, 8.0).toInt().coerceIn(0, 100),
            minFee = d(s.child("minEntryFee").value, 10.0).coerceAtLeast(0.0),
            daily = d(s.child("dailyLimit").value, 3.0).toInt().coerceIn(0, 100),
            cooldownDays = d(s.child("cooldownDays").value, 0.0).coerceIn(0.0, 365.0),
            lockAll = d(s.child("lockAll").value, 0.0).coerceAtLeast(0.0),
            creditTo = if (s.child("creditTo").value == "winning") "winning" else "deposited",
            countPast = s.child("countPast").value == true,
            amounts = amounts, weights = weights
        )
    }

    /** Matches the player joined that count for the task: ongoing / completed and entry fee >= the admin minimum. */
    private suspend fun qualified(uid: String, minFee: Double): Int {
        val joined = Repo.db.child("joinedByUser").child(uid).get().await()
        val entries = joined.children.toList().takeLast(300)
        var n = 0
        for (chunk in entries.chunked(25)) {
            val rows = coroutineScope { chunk.map { e -> async { qualifies(e, minFee) } }.awaitAll() }
            n += rows.count { it }
        }
        return n
    }

    private suspend fun qualifies(e: DataSnapshot, minFee: Double): Boolean {
        val id = e.key ?: return false
        return try {
            val st = Repo.db.child("matches").child(id).child("status").get().await().value as? String
            if (st != "ongoing" && st != "completed") {
                false
            } else {
                var fee = (e.child("entryFee").value as? Number)?.toDouble() ?: Double.NaN
                var type = e.child("type").value as? String
                if (fee.isNaN()) {
                    fee = d(Repo.db.child("matches").child(id).child("entryFee").get().await().value)
                    type = Repo.db.child("matches").child(id).child("type").get().await().value as? String
                }
                val f = if (type.equals("FREE", ignoreCase = true)) 0.0 else fee
                f + 1e-9 >= minFee
            }
        } catch (ex: kotlinx.coroutines.CancellationException) {
            throw ex
        } catch (ex: Exception) {
            false
        }
    }

    private suspend fun loadCtx(): Ctx {
        val uid = Repo.uid()
        if (uid.isEmpty()) throw IllegalStateException("not signed in")
        val db = Repo.db
        val cfg = parseCfg(db.child("spinConfig").get().await())
        val uc = safe { db.child("spinUserCfg").child(uid).get().await() }
        val bonus = safe { d(db.child("spinBonus").child(uid).get().await().value).toInt().coerceIn(0, 1000) } ?: 0
        val ss = db.child("spinState").child(uid).get().await()
        val q = qualified(uid, cfg.minFee)
        val st = St(
            exists = ss.child("init").value == true,
            consumed = d(ss.child("consumed").value).toLong().coerceAtLeast(0L),
            dayStart = d(ss.child("dayStart").value).toLong(),
            dayCount = d(ss.child("dayCount").value).toLong().coerceAtLeast(0L),
            totalSpins = d(ss.child("totalSpins").value).toLong().coerceAtLeast(0L),
            totalEarned = d(ss.child("totalEarned").value).coerceAtLeast(0.0),
            lastNormalAt = d(ss.child("lastNormalAt").value).toLong()
        )
        return Ctx(cfg, d(uc?.child("lock")?.value).coerceAtLeast(0.0), uc?.child("blocked")?.value == true, bonus, st, q)
    }

    private suspend fun fetchOffset(): Long = suspendCancellableCoroutine { cont ->
        FirebaseDatabase.getInstance().getReference(".info/serverTimeOffset").addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(s: DataSnapshot) { if (cont.isActive) cont.resume(d(s.value).toLong()) }
            override fun onCancelled(e: DatabaseError) { if (cont.isActive) cont.resume(0L) }
        })
    }

    /** Server time (the phone clock + the offset Firebase tells us). */
    private suspend fun now(): Long {
        var o = offset
        if (o == null) {
            o = safe { fetchOffset() } ?: 0L
            offset = o
        }
        return System.currentTimeMillis() + o
    }

    private fun dayStart(now: Long): Long = (now + IST_MS) - ((now + IST_MS) % DAY_MS)

    /**
     * Lock level -> highest reward that can come (the database rules use the SAME steps):
     * up to 5 -> 5, up to 10 -> 10, up to 25 -> 25, up to 50 -> 50, up to 80 -> 150 (never 200 / 500 / 1000), 81 or more -> whole wheel.
     * So lock 6, 7, 8, 9 gives the chance of 5 or 10 coins and a bigger lock opens bigger rewards.
     */
    private fun capOf(c: Ctx): Double {
        val lock = if (c.lock > 0.0) c.lock else c.cfg.lockAll
        return when {
            lock <= 0.0 -> 2.0 // lock 0 = only 2 coins
            lock <= 5.0 -> 5.0
            lock <= 10.0 -> 10.0
            lock <= 25.0 -> 25.0
            lock <= 50.0 -> 50.0
            lock <= 80.0 -> 150.0
            else -> Double.POSITIVE_INFINITY
        }
    }

    private fun eligible(cfg: Cfg, cap: Double): List<Int> =
        cfg.amounts.indices.filter { cfg.weights[it] > 0.0 && cfg.amounts[it] <= cap + 1e-9 }

    private fun pick(cfg: Cfg, cap: Double): Int {
        val idx = eligible(cfg, cap)
        if (idx.isEmpty()) return -1
        var total = 0.0
        for (i in idx) total += cfg.weights[i]
        if (total <= 0.0) return idx[Random.nextInt(idx.size)]
        var r = Random.nextDouble() * total
        for (i in idx) {
            r -= cfg.weights[i]
            if (r < 0.0) return i
        }
        return idx.last()
    }

    private fun evaluate(c: Ctx, now: Long): Ev {
        val cfg = c.cfg
        val st = c.st
        val consumed = if (st.exists) st.consumed else if (cfg.countPast) 0L else c.qualified.toLong()
        val available = (c.qualified - consumed).coerceAtLeast(0L).toInt()
        val today = dayStart(now)
        val todayCount = if (st.exists && st.dayStart == today) st.dayCount.toInt() else 0
        val next = if (cfg.cooldownDays > 0.0 && st.lastNormalAt > 0L) st.lastNormalAt + (cfg.cooldownDays * DAY_MS).toLong() else 0L
        var reason = ""
        var useBonus = false
        if (!cfg.enabled) reason = "disabled"
        else if (c.blocked) reason = "blocked"
        else if (eligible(cfg, capOf(c)).isEmpty()) reason = "not_configured"
        else if (c.bonus > 0) useBonus = true // free spins from the admin skip the match task, daily limit and cooldown
        else if (available < cfg.required) reason = "need_matches"
        else if (cfg.daily > 0 && todayCount >= cfg.daily) reason = "daily_limit"
        else if (next > now) reason = "cooldown"
        return Ev(reason.isEmpty(), reason, useBonus, available, todayCount, if (reason == "cooldown") next else 0L)
    }

    private fun message(reason: String): String = when (reason) {
        "disabled" -> "Lucky Wheel is not available right now"
        "blocked" -> "Lucky Wheel is not available for your account"
        "not_configured" -> "Lucky Wheel is being set up. Try again later"
        "daily_limit" -> "Daily spin limit reached. Come back tomorrow"
        "cooldown" -> "Next spin is not available yet"
        else -> ""
    }

    private fun view(c: Ctx, ev: Ev): SpinStatus = SpinStatus(
        enabled = c.cfg.enabled, canSpin = ev.canSpin, reason = ev.reason, message = message(ev.reason),
        required = c.cfg.required, available = ev.available, minEntryFee = c.cfg.minFee,
        dailyLimit = c.cfg.daily, todayCount = ev.todayCount, nextSpinAt = ev.nextSpinAt,
        totalEarned = c.st.totalEarned, totalSpins = c.st.totalSpins, bonus = c.bonus,
        segments = c.cfg.amounts, creditTo = c.cfg.creditTo
    )

    private fun friendly(e: Exception?): String {
        val m = e?.message.orEmpty()
        return if (m.contains("permission", ignoreCase = true)) "Lucky Wheel is not ready. Admin must publish the latest database rules"
        else "No connection. Try again"
    }

    /** First visit: remember the starting point so old matches are not counted (unless the admin allowed it). */
    private suspend fun ensureInit(c: Ctx) {
        val m = hashMapOf<String, Any?>(
            "init" to true, "consumed" to (if (c.cfg.countPast) 0L else c.qualified.toLong()),
            "dayStart" to 0L, "dayCount" to 0L, "totalSpins" to 0L, "totalEarned" to 0L,
            "lastAt" to 0L, "lastNormalAt" to 0L, "lastAmount" to 0L, "lastBonus" to false, "lastWallet" to "none"
        )
        Repo.db.child("spinState").child(Repo.uid()).setValue(m).await()
    }

    suspend fun status(): SpinOutcome<SpinStatus> {
        return try {
            var c = loadCtx()
            if (c.cfg.enabled && !c.st.exists) {
                safe { ensureInit(c) }
                c = safe { loadCtx() } ?: c
            }
            cached = c
            cachedAt = System.currentTimeMillis()
            SpinOutcome(view(c, evaluate(c, now())), null)
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            SpinOutcome<SpinStatus>(null, friendly(e))
        }
    }

    suspend fun spin(): SpinOutcome<SpinResult> {
        try {
            val uid = Repo.uid()
            // Use the data the screen already loaded (fresh for 2 minutes) so the wheel can start at once.
            // If it was stale, the write is refused and the retry loop below reloads everything.
            val fresh = cached?.takeIf { System.currentTimeMillis() - cachedAt < 120_000L }
            var c = fresh ?: loadCtx()
            if (!c.st.exists && c.cfg.enabled) {
                safe { ensureInit(c) }
                c = loadCtx()
            }
            if (!c.st.exists) return SpinOutcome<SpinResult>(null, "Lucky Wheel is not ready yet. Please try again")
            val username = safe { Repo.db.child("users").child(uid).child("username").get().await().value as? String } ?: ""
            var lastErr: Exception? = null
            for (attempt in 1..3) {
                if (attempt > 1) c = loadCtx()
                val now = now()
                val ev = evaluate(c, now)
                if (!ev.canSpin) return SpinOutcome<SpinResult>(null, if (ev.reason == "need_matches") "Play more matches to unlock Lucky Wheel" else message(ev.reason))
                val cap = capOf(c)
                val idx = pick(c.cfg, cap)
                if (idx < 0) return SpinOutcome<SpinResult>(null, message("not_configured"))
                val amount = c.cfg.amounts[idx]
                val wallet = c.cfg.creditTo
                val cur = d(Repo.db.child("users").child(uid).child(wallet).get().await().value)
                val key = Repo.db.child("spinLog").push().key ?: return SpinOutcome<SpinResult>(null, "Something went wrong. Try again")
                val st = c.st
                val bonusSpin = ev.useBonus
                val today = dayStart(now)
                val ts = ServerValue.TIMESTAMP
                val newState = hashMapOf<String, Any?>(
                    "init" to true,
                    "consumed" to (if (bonusSpin) st.consumed else st.consumed + c.cfg.required),
                    "dayStart" to (if (bonusSpin) st.dayStart else today),
                    "dayCount" to (if (bonusSpin) st.dayCount else (if (st.dayStart == today) st.dayCount else 0L) + 1L),
                    "totalSpins" to st.totalSpins + 1L,
                    "totalEarned" to st.totalEarned + amount,
                    "lastAt" to ts,
                    "lastNormalAt" to (if (bonusSpin) st.lastNormalAt else ts),
                    "lastAmount" to amount,
                    "lastBonus" to bonusSpin,
                    "lastWallet" to wallet
                )
                val updates = hashMapOf<String, Any?>(
                    "spinState/$uid" to newState,
                    "users/$uid/$wallet" to cur + amount,
                    "spinHistory/$uid/$key" to hashMapOf<String, Any?>("amount" to amount, "ts" to ts, "wallet" to wallet, "bonus" to bonusSpin),
                    "spinLog/$key" to hashMapOf<String, Any?>(
                        "uid" to uid, "username" to username, "amount" to amount, "ts" to ts, "bonus" to bonusSpin, "wallet" to wallet,
                        "cap" to (if (cap.isInfinite()) 0.0 else cap)
                    ),
                    "transactions/$uid/spin_$key" to hashMapOf<String, Any?>(
                        "id" to "spin_$key", "type" to "spin", "amount" to amount, "note" to "Lucky Wheel reward",
                        "wallet" to wallet, "ts" to ts, "status" to "success"
                    )
                )
                if (bonusSpin) updates["spinBonus/$uid"] = if (c.bonus > 1) (c.bonus - 1).toLong() else null
                try {
                    Repo.db.updateChildren(updates).await()
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e
                } catch (e: Exception) {
                    lastErr = e
                    continue
                }
                // No slow reload here: build the new status locally, the screen refreshes it after the popup.
                cached = null
                val left = if (bonusSpin) (c.bonus - 1).coerceAtLeast(0) else c.bonus
                val v = view(c, ev)
                val after = v.copy(
                    canSpin = bonusSpin && left > 0, reason = "", message = "", bonus = left,
                    available = if (bonusSpin) v.available else (v.available - c.cfg.required).coerceAtLeast(0),
                    todayCount = if (bonusSpin) v.todayCount else v.todayCount + 1,
                    totalEarned = v.totalEarned + amount, totalSpins = v.totalSpins + 1L
                )
                return SpinOutcome(SpinResult(amount, idx, after), null)
            }
            return SpinOutcome<SpinResult>(null, friendly(lastErr))
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            return SpinOutcome<SpinResult>(null, friendly(e))
        }
    }
}

object SpinRepo {
    fun config() = Repo.watch(Repo.db.child("spinConfig")) { s ->
        val games = s.child("games").children.filter { it.value == true }.mapNotNull { it.key }.toSet()
        SpinCfg(enabled = s.child("enabled").value == true, games = games)
    }

    fun history() = Repo.watch(Repo.db.child("spinHistory").child(Repo.uid().ifEmpty { "_" }).orderByChild("ts").limitToLast(50)) { s ->
        s.children.mapNotNull { c ->
            val a = (c.child("amount").value as? Number)?.toDouble()
            if (a == null) null else SpinHist(a, (c.child("ts").value as? Number)?.toLong() ?: 0L)
        }.sortedByDescending { it.ts }
    }

    fun bonus() = Repo.watch(Repo.db.child("spinBonus").child(Repo.uid().ifEmpty { "_" })) { s ->
        ((s.value as? Number)?.toInt() ?: 0).coerceAtLeast(0)
    }

    fun totals() = Repo.watch(Repo.db.child("spinState").child(Repo.uid().ifEmpty { "_" })) { s ->
        ((s.child("totalEarned").value as? Number)?.toDouble() ?: 0.0) to ((s.child("totalSpins").value as? Number)?.toLong() ?: 0L)
    }
}

// Wheel piece colours are PERMANENT (same in every theme), taken from the reference screenshot, in wheel order:
// pink-red, light orange, green, blue, orange, red, mint, light blue.
private val WheelColors = listOf(
    Color(0xFFFE3B5B), Color(0xFFFE9F43), Color(0xFF10AC84), Color(0xFF2E86DF),
    Color(0xFFF39C11), Color(0xFFEE5253), Color(0xFF1DD0A0), Color(0xFF54A0FE)
)
private val GoldC = Color(0xFFFFC83D)

// ---- Lucky Wheel page: everything OUTSIDE the wheel is PERMANENT (same in every theme), colours taken from the reference screenshot. ----
private val SpinPageBrush = Brush.linearGradient(
    0.0f to Color(0xFF230D3C), 0.45f to Color(0xFF0A0911), 1.0f to Color(0xFF291D0F),
    start = Offset(0f, 0f), end = Offset(1100f, 2400f)
)
private val SpinCardC = Color.White.copy(alpha = 0.07f)          // glass card
private val SpinCardBorder = Color.White.copy(alpha = 0.10f)
private val SpinGrayC = Color(0xFF9E9AAE)                        // soft grey text
private val SpinTrackC = Color(0xFF1E1D25)                       // progress track / locked button
private val SpinRedC = Color(0xFFE63757)                         // LOCKED pill
private val SpinGreenC = Color(0xFF22C55E)                       // UNLOCKED pill / positive amounts
private val SpinOrangeC = Color(0xFFFE9F43)

/** Fixed dark-purple page background + white text, whatever theme the app is using. */
@Composable
private fun SpinPage(content: @Composable () -> Unit) {
    Box(Modifier.fillMaxSize().background(SpinPageBrush)) {
        androidx.compose.runtime.CompositionLocalProvider(androidx.compose.material3.LocalContentColor provides Color.White) { content() }
    }
}

private fun Modifier.spinCard(radius: Int): Modifier =
    this.clip(RoundedCornerShape(radius.dp)).background(SpinCardC).border(1.dp, SpinCardBorder, RoundedCornerShape(radius.dp))

@Composable
private fun SpinBtn(text: String, modifier: Modifier = Modifier, active: Boolean, enabled: Boolean, onClick: () -> Unit) {
    Button(onClick, modifier.height(44.dp), enabled = enabled, shape = RoundedCornerShape(8.dp), contentPadding = PaddingValues(horizontal = 16.dp),
        colors = ButtonDefaults.buttonColors(containerColor = if (active) GoldC else SpinTrackC, contentColor = if (active) Color.Black else SpinGrayC,
            disabledContainerColor = if (active) GoldC.copy(alpha = 0.6f) else SpinTrackC, disabledContentColor = if (active) Color.Black else SpinGrayC)) {
        Text(text, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }
}

private fun wheelColor(i: Int, n: Int): Color {
    var k = i % WheelColors.size
    // the last piece must not have the same colour as the first one
    if (i == n - 1 && n > 1 && k == 0) k = 4
    return WheelColors[k]
}

/** Banner on the match list of a game where the admin turned the Lucky Wheel on. */
@Composable
fun SpinBanner(nav: NavController, gameId: String) {
    val cfg by rflow(init = SpinCfg()) { SpinRepo.config() }
    val free by rflow(init = 0) { SpinRepo.bonus() }
    // Shown in the games the admin chose - and always when the player has free spins from the admin.
    if (!cfg.enabled || (gameId !in cfg.games && free <= 0)) return
    // PERMANENT look (measured from the reference screenshot): fixed 70dp card, purple -> black gradient, dark-red SPIN pill.
    // Nothing here reads the app theme, so it never changes with any theme.
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp).height(70.dp)
            .clip(RoundedCornerShape(12.dp)).background(SpinBannerBrush)
            .clickable { nav.go("spin") }.padding(horizontal = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("\uD83C\uDFA1", fontSize = 14.sp)
                Spacer(Modifier.width(6.dp))
                Text(tx("Lucky Wheel"), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1)
            }
            if (free > 0) Text(tx("Free spins from admin") + ": $free", color = GoldC, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            else Text(tx("Play Matches & Win Rewards"), color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
        Spacer(Modifier.width(8.dp))
        Box(Modifier.size(width = 57.dp, height = 34.dp).clip(RoundedCornerShape(50)).background(SpinBannerBtn), contentAlignment = Alignment.Center) {
            Text(tx("SPIN"), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1)
        }
    }
}

/** Lucky Wheel banner look is PERMANENT (same in every theme): left #4F3773 fading to near-black #030102 on the right, SPIN pill #AF0D08. */
private val SpinBannerBrush = androidx.compose.ui.graphics.Brush.horizontalGradient(listOf(Color(0xFF4F3773), Color(0xFF030102)))
private val SpinBannerBtn = Color(0xFFAF0D08)

@Composable
private fun SpinTopBar(title: String, nav: NavController, action: String? = null, onAction: () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.AutoMirrored.Filled.ArrowBack, null, Modifier.size(22.dp).clickable { nav.back() })
        Spacer(Modifier.width(14.dp))
        Text(title, Modifier.weight(1f), fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        if (action != null) {
            Box(Modifier.clip(RoundedCornerShape(50)).background(GoldC).clickable { onAction() }.padding(horizontal = 14.dp, vertical = 5.dp)) {
                Text(action, color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun SpinWheel(segments: List<Double>, rotation: () -> Float, modifier: Modifier = Modifier) {
    val labels = remember(segments) { segments.map { money(it) } }
    val paint = remember {
        android.graphics.Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.WHITE
            textAlign = android.graphics.Paint.Align.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setShadowLayer(3f, 0f, 1f, 0x99000000.toInt())
        }
    }
    val hubPaint = remember {
        android.graphics.Paint().apply {
            isAntiAlias = true
            color = GoldC.toArgb()
            textAlign = android.graphics.Paint.Align.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
    }
    Canvas(modifier) {
        val n = segments.size.coerceAtLeast(2)
        val sweep = 360f / n
        val c = Offset(size.width / 2f, size.height / 2f)
        val outer = min(size.width, size.height) / 2f
        val inner = outer * 0.92f
        // gold ring
        drawCircle(
            brush = Brush.sweepGradient(listOf(Color(0xFFFFE082), Color(0xFFFFA000), Color(0xFFFFE082), Color(0xFFB26A00), Color(0xFFFFE082)), c),
            radius = outer, center = c
        )
        rotate(rotation(), c) {
            for (i in 0 until n) {
                drawArc(
                    color = wheelColor(i, n), startAngle = -90f - sweep / 2f + i * sweep, sweepAngle = sweep, useCenter = true,
                    topLeft = Offset(c.x - inner, c.y - inner), size = Size(inner * 2f, inner * 2f)
                )
            }
            for (i in 0 until n) {
                val a = Math.toRadians((-90f - sweep / 2f + i * sweep).toDouble())
                drawLine(Color(0x66FFFFFF), c, Offset(c.x + (inner * cos(a)).toFloat(), c.y + (inner * sin(a)).toFloat()), 2f)
            }
            val cv = drawContext.canvas.nativeCanvas
            for (i in labels.indices) {
                paint.textSize = outer * (if (labels[i].length > 4) 0.095f else 0.115f)
                cv.save()
                cv.rotate(i * sweep, c.x, c.y)
                cv.drawText(labels[i], c.x, c.y - inner * 0.70f + paint.textSize / 3f, paint)
                cv.restore()
            }
        }
        // lights on the ring
        for (i in 0 until 16) {
            val a = Math.toRadians((i * 22.5).toDouble())
            drawCircle(Color.White, outer * 0.018f, Offset(c.x + ((outer + inner) / 2f * cos(a)).toFloat(), c.y + ((outer + inner) / 2f * sin(a)).toFloat()))
        }
        // centre hub
        drawCircle(GoldC, outer * 0.19f, c)
        drawCircle(Color(0xFF1A0536), outer * 0.155f, c)
        hubPaint.textSize = outer * 0.085f
        drawContext.canvas.nativeCanvas.drawText("SPIN", c.x, c.y + hubPaint.textSize / 3f, hubPaint)
    }
}

@Composable
private fun SpinPointer(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val p = Path().apply {
            moveTo(size.width / 2f, size.height)
            lineTo(0f, 0f)
            lineTo(size.width, 0f)
            close()
        }
        drawPath(p, GoldC)
        drawPath(p, Color(0xFF8A5A00), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3f))
    }
}

@Composable
fun SpinScreen(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val me by rflow(init = User()) { Repo.me() }
    val freeLive by rflow(init = 0) { SpinRepo.bonus() }
    var status by remember { mutableStateOf<SpinStatus?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var spinning by remember { mutableStateOf(false) }
    var won by remember { mutableStateOf<Double?>(null) }
    var wheel by remember { mutableStateOf<List<Double>>(emptyList()) }
    val rotation = remember { Animatable(0f) }
    val dateFmt = remember { SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()) }

    suspend fun load() {
        val o = SpinApi.status()
        val v = o.value
        if (v != null) {
            status = v
            error = null
            if (!spinning) wheel = v.segments
        } else if (status == null) {
            error = o.error ?: "Something went wrong. Try again"
        } else {
            ctx.toast(tx(o.error ?: "Something went wrong. Try again"))
        }
    }

    LaunchedEffect(Unit) { load() }
    // admin gave / removed free spins while the screen is open -> refresh so the player can spin right away
    LaunchedEffect(freeLive) { if (status != null && !spinning && status?.bonus != freeLive) load() }

    fun doSpin() {
        val st = status ?: return
        if (spinning || !st.canSpin) return
        spinning = true
        scope.launch {
            // The wheel starts turning the moment SPIN is tapped; the result is fetched while it turns.
            val free = launch { rotation.animateTo(rotation.value + 360f * 120f, tween(60_000, easing = LinearEasing)) }
            try {
                val o = SpinApi.spin()
                val r = o.value
                free.cancel()
                if (r == null) {
                    rotation.snapTo(rotation.value % 360f)
                    ctx.toast(tx(o.error ?: "Something went wrong. Try again"))
                    load()
                    return@launch
                }
                val segs = if (r.status.segments.size >= 2) r.status.segments else wheel
                wheel = segs
                if (r.index in segs.indices) {
                    val sweep = 360f / segs.size
                    val base = ((rotation.value % 360f) + 360f) % 360f
                    val jitter = (Random.nextFloat() - 0.5f) * sweep * 0.5f
                    val target = (((360f - r.index * sweep) % 360f) + jitter + 360f) % 360f
                    var delta = target - base
                    if (delta < 0f) delta += 360f
                    rotation.animateTo(rotation.value + 360f * 3f + delta, tween(3600, easing = CubicBezierEasing(0.2f, 0.8f, 0.25f, 1f)))
                    rotation.snapTo(rotation.value % 360f)
                }
                status = r.status
                won = r.amount
            } catch (e: kotlinx.coroutines.CancellationException) {
                free.cancel()
                throw e
            } catch (e: Exception) {
                free.cancel()
                ctx.toast(tx("Something went wrong. Try again"))
            } finally {
                free.cancel()
                spinning = false
            }
        }
    }

    SpinPage {
    Column(Modifier.fillMaxSize()) {
        SpinTopBar(tx("Lucky Wheel"), nav, tx("History")) { nav.go("spinhistory") }
        val st = status
        if (st == null) {
            if (error != null) {
                Column(Modifier.fillMaxSize().padding(30.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text(tx(error ?: ""), color = SpinGrayC, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(14.dp))
                    Btn(tx("RETRY")) { error = null; scope.launch { load() } }
                }
            } else Loader()
            return@Column
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            // headline
            val head = when {
                st.canSpin && st.bonus > 0 -> tx("Free spins from admin") + ": ${st.bonus}. " + tx("Tap SPIN NOW")
                st.canSpin -> tx("Lucky Wheel is unlocked! Tap SPIN NOW")
                st.reason == "need_matches" -> {
                    val more = (st.required - st.available).coerceAtLeast(1)
                    tx("Play") + " $more " + tx(if (more == 1) "more match to unlock Lucky Wheel" else "more matches to unlock Lucky Wheel")
                }
                else -> tx(st.message.ifBlank { "Lucky Wheel is not available right now" })
            }
            Text(head, Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp), fontSize = 17.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 14.dp).spinCard(8).padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(tx("Player ID"), color = SpinGrayC, fontSize = 13.sp, modifier = Modifier.weight(1f))
                Text(me.username, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
            if (st.bonus > 0) {
                Spacer(Modifier.height(10.dp))
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 14.dp).clip(RoundedCornerShape(8.dp)).background(GoldC.copy(alpha = 0.16f))
                        .border(1.dp, GoldC, RoundedCornerShape(8.dp)).padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("\uD83C\uDF81 " + tx("Free spins from admin"), color = GoldC, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    Text("${st.bonus}", color = GoldC, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                }
            }
            Spacer(Modifier.height(18.dp))
            // wheel + pointer
            Box(Modifier.fillMaxWidth(0.70f).widthIn(max = 280.dp).aspectRatio(1f)) {   // smaller wheel, centred
                if (wheel.size >= 2) SpinWheel(wheel, { rotation.value }, Modifier.fillMaxSize())
                SpinPointer(Modifier.align(Alignment.TopCenter).offset(y = (-6).dp).size(width = 24.dp, height = 30.dp))
            }
            Spacer(Modifier.height(20.dp))
            // lock card
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 14.dp).spinCard(12).padding(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                val ok = st.canSpin
                Box(Modifier.clip(RoundedCornerShape(50)).background((if (ok) SpinGreenC else SpinRedC).copy(alpha = 0.18f)).padding(horizontal = 14.dp, vertical = 4.dp)) {
                    Text(if (ok) "\uD83D\uDD13 " + tx("UNLOCKED") else "\uD83D\uDD12 " + tx("LOCKED"), color = if (ok) SpinGreenC else SpinRedC, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
                if (st.required > 0) {
                    Spacer(Modifier.height(10.dp))
                    Text(
                        tx("Play paid matches with entry fee") + " ${money(st.minEntryFee)} " + tx("or more to unlock"),
                        color = SpinGrayC, fontSize = 12.sp, textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth()) {
                        Text(tx("Match Requirement"), fontSize = 12.sp, modifier = Modifier.weight(1f))
                        Text("${min(st.available, st.required)} / ${st.required}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { (min(st.available, st.required).toFloat() / st.required.toFloat()).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(50)), color = GoldC, trackColor = SpinTrackC
                    )
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    tx("Today's Completed Spins") + ": " + st.todayCount + " / " + (if (st.dailyLimit > 0) st.dailyLimit.toString() else "\u221E"),
                    fontSize = 12.sp, fontWeight = FontWeight.SemiBold
                )
                if (st.reason == "cooldown" && st.nextSpinAt > 0L) {
                    Spacer(Modifier.height(6.dp))
                    Text(tx("Next spin") + ": " + dateFmt.format(Date(st.nextSpinAt)), color = SpinOrangeC, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(14.dp))
            SpinBtn(
                if (spinning) tx("SPINNING...") else if (st.canSpin) tx("SPIN NOW") else tx("LOCKED"),
                Modifier.fillMaxWidth().padding(horizontal = 14.dp),
                active = st.canSpin, enabled = st.canSpin && !spinning
            ) { doSpin() }
            Spacer(Modifier.height(14.dp))
            Text(
                tx("Play paid matches and unlock your spin reward.") + " " +
                    (if (st.creditTo == "winning") tx("Rewards are credited to your winning wallet.") else tx("Rewards are credited to your join wallet.")),
                Modifier.padding(horizontal = 24.dp), color = SpinGrayC, fontSize = 12.sp, textAlign = TextAlign.Center
            )
        }
    }
    }
    won?.let { amount -> SpinWinDialog(amount) { won = null; scope.launch { load() } } }
}

@Composable
fun SpinHistoryScreen(nav: NavController) {
    val totals by rflow(init = (0.0 to 0L)) { SpinRepo.totals() }
    val listN by rflow(init = null as List<SpinHist>?) { SpinRepo.history() }
    val fmt = remember { SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()) }
    SpinPage {
    Column(Modifier.fillMaxSize()) {
        SpinTopBar(tx("Spin History"), nav)
        Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Column(Modifier.weight(1f).spinCard(10).padding(vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(tx("TOTAL EARNED"), color = SpinGrayC, fontSize = 11.sp)
                Row(verticalAlignment = Alignment.CenterVertically) { CoinIcon(18); Spacer(Modifier.width(4.dp)); Text(money(totals.first), fontWeight = FontWeight.Bold, fontSize = 20.sp, color = GoldC) }
            }
            Column(Modifier.weight(1f).spinCard(10).padding(vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(tx("TOTAL SPINS"), color = SpinGrayC, fontSize = 11.sp)
                Text("${totals.second}", fontWeight = FontWeight.Bold, fontSize = 20.sp)
            }
        }
        Text(tx("Recent Rewards"), Modifier.padding(horizontal = 14.dp), fontWeight = FontWeight.Bold, fontSize = 15.sp)
        val list = listN
        if (list == null) { Loader(); return@Column }
        if (list.isEmpty()) {
            Text(tx("No spin history available yet."), Modifier.fillMaxWidth().padding(40.dp), textAlign = TextAlign.Center, color = SpinGrayC)
        } else {
            LazyColumn(contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(list) { h ->
                    Row(Modifier.fillMaxWidth().spinCard(10).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(tx("Lucky Wheel reward"), fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                            Text(fmt.format(Date(h.ts)), color = SpinGrayC, fontSize = 12.sp)
                        }
                        Text("+" + money(h.amount), color = SpinGreenC, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }
            }
        }
    }
    }
}

private class ConfettiPiece(val x: Float, val phase: Float, val speed: Float, val size: Float, val color: Color, val sway: Float, val spin: Float)
private val ConfettiColors = listOf(Color(0xFFFFC83D), Color(0xFFEF4444), Color(0xFF3B82F6), Color(0xFF10B981), Color(0xFFEC4899), Color(0xFF8B5CF6), Color.White)

/** "Congratulations" popup with falling confetti and a bouncing coin amount. */
@Composable
private fun SpinWinDialog(amount: Double, onClose: () -> Unit) {
    val pieces = remember {
        List(80) {
            ConfettiPiece(
                Random.nextFloat(), Random.nextFloat(), 0.6f + Random.nextFloat() * 0.8f, 8f + Random.nextFloat() * 10f,
                ConfettiColors[Random.nextInt(ConfettiColors.size)], Random.nextFloat() * 0.04f, Random.nextFloat() * 360f
            )
        }
    }
    val t by rememberInfiniteTransition(label = "confetti").animateFloat(0f, 1f, infiniteRepeatable(tween(3600, easing = LinearEasing)), label = "t")
    val pop = remember { Animatable(0.3f) }
    LaunchedEffect(Unit) { pop.animateTo(1f, spring(dampingRatio = 0.45f, stiffness = 300f)) }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                for (p in pieces) {
                    val prog = (t * p.speed + p.phase) % 1f
                    val px = (p.x + sin(prog * 12f + p.phase * 6f) * p.sway) * size.width
                    val py = prog * (size.height + 40f) - 20f
                    rotate(p.spin + prog * 720f, Offset(px, py)) {
                        drawRect(p.color, Offset(px - p.size / 2f, py - p.size / 2f), Size(p.size, p.size * 0.6f))
                    }
                }
            }
            Column(
                Modifier.graphicsLayer { scaleX = pop.value; scaleY = pop.value }.padding(horizontal = 34.dp).fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp)).background(Brush.verticalGradient(listOf(Color(0xFF2B0A5E), Color(0xFF14012F))))
                    .border(2.dp, GoldC, RoundedCornerShape(20.dp)).padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("\uD83C\uDF89", fontSize = 46.sp)
                Text(tx("Congratulations!"), color = GoldC, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
                Spacer(Modifier.height(6.dp))
                Text(tx("You won"), color = Color.White, fontSize = 15.sp)
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CoinIcon(38)
                    Spacer(Modifier.width(8.dp))
                    Text(money(amount), color = GoldC, fontSize = 46.sp, fontWeight = FontWeight.ExtraBold)
                }
                Spacer(Modifier.height(6.dp))
                Text(tx("Reward added to your wallet"), color = Color(0xFFB9B0D6), fontSize = 13.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(18.dp))
                Btn(tx("AWESOME!"), Modifier.fillMaxWidth(), color = SpinOrangeC) { onClose() }
            }
        }
    }
}
