package com.bestwinesport.app

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import java.util.Calendar

// ---------------------------------------------------------------------------------------------------------------
// Player matches: players create matches, others join, the creator shares the Room ID, everybody sends a screenshot,
// the admin picks the winner and the winning coins go to that player's wallet.
// ---------------------------------------------------------------------------------------------------------------

private val ShotBlue = Color(0xFF3D8BFF)

private fun slotLabel(n: Int): String = if (n == 2) "1 vs 1" else "$n " + tx("players")

private fun copyText(ctx: Context, label: String, text: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText(label, text)); ctx.toast(tx("Copied"))
}

private fun pickDateTime(ctx: Context, initial: Long, onPick: (Long) -> Unit) {
    val c = Calendar.getInstance().apply { timeInMillis = initial }
    DatePickerDialog(ctx, { _, y, mo, d ->
        TimePickerDialog(ctx, { _, h, mi ->
            val r = Calendar.getInstance().apply { set(y, mo, d, h, mi, 0); set(Calendar.MILLISECOND, 0) }
            onPick(r.timeInMillis)
        }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), false).show()
    }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).apply { datePicker.minDate = System.currentTimeMillis() - 1000 }.show()
}

private fun statusOf(m: PvpMatch): String = when {
    m.status == "cancelled" -> "cancelled"
    m.resultDeclared || m.status == "completed" -> "completed"
    m.status == "ongoing" -> "ongoing"
    else -> "upcoming"
}

@Composable
private fun StatusTag(m: PvpMatch) {
    val st = statusOf(m)
    val c = when (st) { "ongoing" -> ShotBlue; "completed" -> SuccessC; "cancelled" -> Red; else -> Orange }
    Box(Modifier.clip(RoundedCornerShape(12.dp)).background(c).padding(horizontal = 10.dp, vertical = 3.dp)) {
        Text(tx(st.uppercase()), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
    }
}

/** Fixed light-black (pencil-lead) surface for the boxes / chips of the Player Match pages: same in every theme. */
private val PencilBlack = Color(0xFF141416)

@Composable
private fun PvpChip(text: String, sel: Boolean, onClick: () -> Unit) {
    Box(Modifier.clip(RoundedCornerShape(18.dp)).background(if (sel) Orange else PencilBlack).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp)) {
        Text(text, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun CoinText(label: String, value: Double, modifier: Modifier = Modifier) {
    Column(modifier) {
        Text(label, color = Color.Gray, fontSize = 11.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            CoinIcon(14); Spacer(Modifier.width(4.dp)); Text(money(value), fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
    }
}

/**
 * Player match card: exactly the same look as the Full Map match card.
 * Upcoming = slots + progress bar + JOIN | Ongoing = full-width red SPECTATE | Results = WATCH + JOINED/COMPLETED/CANCELLED.
 * preview = true is used by the Create tab to show how the new match will look (no Match ID yet, not clickable).
 */
@Composable
private fun PvpCard(m: PvpMatch, banner: String, joinedByMe: Boolean, onClick: () -> Unit, onJoin: (() -> Unit)? = null, preview: Boolean = false) {
    val ctx = LocalContext.current
    val st = statusOf(m)
    val full = m.joined >= m.slots
    val canJoin = onJoin != null && st == "upcoming" && !joinedByMe && !full
    val no = if (m.matchNo > 0) m.matchNo.toString() else m.matchCode
    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp).clip(RoundedCornerShape(12.dp)).background(MatchC).slateEdge(RoundedCornerShape(12.dp)).clickable(enabled = !preview, onClick = onClick)) {
        FullImage(banner.ifBlank { m.gameImage }, Modifier.fillMaxWidth(), 0)
        Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Tag(slotLabel(m.slots.toInt()), Red); Tag(m.gameName, Orange)
        }
        Row(Modifier.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Image(androidx.compose.ui.res.painterResource(com.bestwinesport.app.R.drawable.bestwin_loading_logo), null,
                Modifier.size(40.dp).border(2.dp, Color.White, CircleShape).padding(2.dp).clip(CircleShape), contentScale = ContentScale.Crop)
            Spacer(Modifier.width(10.dp))
            Text(if (preview) m.title.ifBlank { m.gameName } else "${m.title.ifBlank { m.gameName }} - Match #$no", Modifier.weight(1f), fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
        if (!preview && m.matchCode.isNotBlank()) Text("Match ID : ${m.matchCode}", Modifier.padding(horizontal = 12.dp, vertical = 1.dp), color = Color.Gray, fontSize = 11.sp)
        if (m.creatorName.isNotBlank()) Text("${tx("Hosted by")} : @${m.creatorName}", Modifier.padding(horizontal = 12.dp, vertical = 4.dp), color = Orange, fontSize = 12.sp)
        HorizontalDivider(Modifier.padding(top = 6.dp), color = Color.Gray)
        Row(Modifier.height(IntrinsicSize.Min)) {
            PvpCell(Modifier.weight(1f)) { Text(matchDate(m.startTime), fontSize = 13.sp, textAlign = TextAlign.Center) }
            VerticalDivider(color = Color.Gray)
            PvpCell(Modifier.weight(1f)) { Text(tx("PRIZE POOL"), color = Orange, fontSize = 12.sp); CoinAmount(money(m.prize), 15) }
            VerticalDivider(color = Color.Gray)
            PvpCell(Modifier.weight(1f)) { Text(tx("PER KILL"), color = Orange, fontSize = 12.sp); CoinAmount(money(0.0), 15) }
        }
        HorizontalDivider(color = Color.Gray)
        Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
            // Coin + entry fee + JOIN / JOINED / FULL / COMPLETED / CANCELLED (same box as the Full Map card).
            val statusBox: @Composable (Modifier) -> Unit = { mod ->
                val bg = when { joinedByMe -> Color(0xFF3FBF9F); st == "cancelled" -> Red; else -> ButtonC }
                val fg = onC(bg)
                Row(mod.height(40.dp).clip(RoundedCornerShape(6.dp)).background(bg).clickable(enabled = !preview, onClick = if (canJoin) onJoin!! else onClick),
                    horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    CoinIcon(18); Spacer(Modifier.width(4.dp)); Text(money(m.entryFee), fontWeight = FontWeight.Bold, color = fg, fontSize = 14.sp)
                    Spacer(Modifier.width(6.dp))
                    Text(when {
                        joinedByMe -> tx("JOINED"); st == "cancelled" -> tx("CANCELLED"); st == "completed" -> tx("COMPLETED")
                        full -> tx("FULL"); canJoin || preview -> tx("JOIN"); else -> tx("NOT JOINED")
                    }, fontWeight = FontWeight.Bold, color = fg, fontSize = 14.sp)
                    if (canJoin || preview) Icon(Icons.Default.ChevronRight, null, Modifier.size(20.dp), tint = fg)
                }
            }
            when (st) {
                // Ongoing: one full-width red SPECTATE box (opens the live link).
                "ongoing" -> Box(Modifier.fillMaxWidth().height(44.dp).clip(RoundedCornerShape(8.dp)).background(SpectateRed)
                    .clickable { openLive(ctx, DEFAULT_WATCH_URL) }, contentAlignment = Alignment.Center) {
                    Text(tx("SPECTATE"), fontWeight = FontWeight.Bold, color = Color.White, fontSize = 15.sp)
                }
                // Results (completed / cancelled): WATCH + status box side by side.
                "completed", "cancelled" -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.weight(1f).height(40.dp).clip(RoundedCornerShape(6.dp)).background(ButtonC)
                        .clickable { openLive(ctx, DEFAULT_WATCH_URL) }, contentAlignment = Alignment.Center) {
                        Text(tx("WATCH"), fontWeight = FontWeight.Bold, color = OnButton, fontSize = 14.sp)
                    }
                    statusBox(Modifier.weight(1f))
                }
                // Upcoming: slots filled + progress bar on the left, JOIN box on the right.
                else -> if (full && !joinedByMe) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("${m.joined}/${m.slots}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            LinearProgressIndicator(progress = { (m.joined.toFloat() / m.slots.toFloat().coerceAtLeast(1f)).coerceIn(0f, 1f) },
                                Modifier.fillMaxWidth().padding(top = 6.dp), color = Purple, trackColor = Color(0xFF4A1C1C))
                        }
                        Box(Modifier.widthIn(min = 150.dp).height(40.dp).clip(RoundedCornerShape(6.dp)).background(Color(0xFF757575)).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
                            Text(tx("MATCH FULL"), fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                        }
                } else Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${m.joined}/${m.slots}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        LinearProgressIndicator(progress = { (m.joined.toFloat() / m.slots.toFloat().coerceAtLeast(1f)).coerceIn(0f, 1f) },
                            Modifier.fillMaxWidth().padding(top = 6.dp), color = Purple, trackColor = Color(0xFF4A1C1C))
                    }
                    statusBox(Modifier.widthIn(min = 150.dp))
                }
            }
        }
    }
}

@Composable
private fun PvpCell(modifier: Modifier, content: @Composable ColumnScope.() -> Unit) =
    Column(modifier.padding(vertical = 6.dp, horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally, content = content)

// ---------------------------------------------------------------------------------------------------------------
// Hub: Join | Create | My matches
// ---------------------------------------------------------------------------------------------------------------
@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun PvpHubScreen(nav: NavController) {
    val pager = androidx.compose.foundation.pager.rememberPagerState(initialPage = 0, pageCount = { 3 })
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize()) {
        BackBar(tx("Player Match"), nav)
        TabsRow(listOf(tx("JOIN MATCH"), tx("CREATE"), tx("MY MATCHES")), pager.currentPage) { i -> scope.launch { pager.animateScrollToPage(i) } }
        HorizontalDivider(color = Color.Gray.copy(alpha = .4f))
        // Swipe left / right to move between Join, Create and My matches.
        androidx.compose.foundation.pager.HorizontalPager(pager, Modifier.weight(1f), beyondBoundsPageCount = 0, verticalAlignment = Alignment.Top) { page ->
            when (page) {
                0 -> PvpJoinTab(nav)
                1 -> PvpCreateTab { scope.launch { pager.animateScrollToPage(2) } }
                else -> PvpMineTab(nav)
            }
        }
    }
}

@Composable
private fun PvpJoinTab(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val user by rflow(init = User()) { Repo.me() }
    val games by rflow(init = emptyList<PvpGame>()) { Repo.pvpGames() }
    val lobbyN by rflow(init = null as List<PvpMatch>?) { Repo.pvpAll() }
    val mineIds by rflow(init = emptyList<PvpMatch>()) { Repo.myPvp() }
    var tab by remember { mutableIntStateOf(1) }
    var gameId by remember { mutableStateOf("") }
    var busyId by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf<PvpMatch?>(null) }
    var joinIgn by remember { mutableStateOf("") }
    val lobby = lobbyN ?: return MatchSkeletonList()
    val me = Repo.uid()
    val keys = listOf("ongoing", "upcoming", "completed")
    confirm?.let { m ->
        AppDialog(tx("Join this match?"), { confirm = null }, tx("JOIN"), {
            confirm = null; busyId = m.id; val ign = joinIgn
            scope.launch {
                val err = Repo.joinPvp(m, user.username, ign); busyId = ""
                if (err == null) { ctx.toast(tx("Joined! Open the match to see the Room ID.")); nav.navigate("pvpmatch/${m.id}") } else ctx.toast(err)
            }
        }, tx("CANCEL"), confirmEnabled = joinIgn.isNotBlank()) {
            Text("${m.label()} • ${slotLabel(m.slots.toInt())}", fontWeight = FontWeight.Bold)
            Text("${tx("Entry fee")}: ${money(m.entryFee)}   ${tx("Winning")}: ${money(m.prize)}")
            DialogNameField(joinIgn, { joinIgn = it.take(30) }, tx("Your in-game name"), Modifier.padding(top = 8.dp))
            Text(tx("The entry fee is taken from your wallet now."), fontSize = 12.sp, color = Color.Gray)
        }
    }
    androidx.activity.compose.BackHandler(gameId.isNotBlank()) { gameId = "" }
    StepSlide(gameId, { from, to -> from.isBlank() && to.isNotBlank() }) { selGame ->
    if (selGame.isBlank()) {
        // Game categories like the Tournaments screen: image + name, 3 in a row, then the next 3 below.
        if (games.isEmpty()) Text(tx("Match not found"), Modifier.fillMaxWidth().padding(40.dp), textAlign = TextAlign.Center, color = Color.Gray)
        androidx.compose.foundation.lazy.grid.LazyVerticalGrid(androidx.compose.foundation.lazy.grid.GridCells.Fixed(3), Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 9.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(17.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
            gridItems(games) { g ->
                Column(Modifier.clip(RoundedCornerShape(10.dp)).background(PvpCardC).bounceClick { gameId = g.id }) {
                    Box {
                        AsyncImage(g.image.ifBlank { g.bannerUrl() }, null, Modifier.fillMaxWidth().aspectRatio(1.23f), contentScale = ContentScale.Crop)
                    }
                    Text(g.name, Modifier.fillMaxWidth().background(LabelC).padding(vertical = 4.dp, horizontal = 2.dp), textAlign = TextAlign.Center, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1, color = onC(LabelC))
                }
            }
        }
    } else {
    val rows = lobby.filter { it.gameId == selGame && statusOf(it) == keys[tab] }
        .sortedBy { if (tab == 2) -it.startTime else it.startTime }
    val skel = rememberTapSkeleton("$selGame/$tab", showFirst = true)   // tap on a game or on a tab: grey cards for a moment, then the list
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, null, Modifier.size(22.dp).clickable { gameId = "" })
            Spacer(Modifier.width(12.dp))
            Text(games.firstOrNull { it.id == selGame }?.name.orEmpty(), color = Purple, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        }
        TabsRow(listOf(tx("ONGOING"), tx("UPCOMING"), tx("RESULTS")), tab) { tab = it }
        if (skel) MatchSkeletonList()
        else if (rows.isEmpty()) EmptyMatches(keys[tab])
        else LazyColumn(contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)) {
            items(rows, key = { it.id }) { m ->
                val mine = m.creatorUid == me || mineIds.any { it.id == m.id }
                PvpCard(m, games.firstOrNull { it.id == m.gameId }?.bannerUrl().orEmpty(), mine, { nav.go("pvpmatch/${m.id}") }, { if (busyId.isBlank()) confirm = m })
            }
        }
    }
    }
    }
}

@Composable
private fun PvpCreateTab(onCreated: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val user by rflow(init = User()) { Repo.me() }
    val gamesN by rflow(init = null as List<PvpGame>?) { Repo.pvpGames() }
    var gameId by remember { mutableStateOf("") }
    var slots by remember { mutableIntStateOf(2) }
    var feeText by remember { mutableStateOf("") }
    var startTime by remember { mutableLongStateOf(System.currentTimeMillis() + 30 * 60_000L) }
    var note by remember { mutableStateOf("") }
    var ign by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf(false) }
    val games = gamesN ?: return MatchSkeletonList()
    if (games.isEmpty()) {
        Text(tx("No games are open for player matches yet."), Modifier.fillMaxWidth().padding(40.dp), textAlign = TextAlign.Center, color = Color.Gray)
        return
    }
    val game = games.firstOrNull { it.id == gameId } ?: games.first()
    val options = game.slotOptions()
    val players = if (slots in options) slots else options.first()
    val fee = feeText.toDoubleOrNull() ?: 0.0
    val feeOk = fee >= Pvp.MIN_FEE
    val prize = if (feeOk) Pvp.prize(fee, players, game.commission) else 0.0
    val canPay = feeOk && user.balance() >= fee
    fun create() {
        busy = true
        scope.launch {
            val err = Repo.createPvp(game, players, fee, startTime, note, user.username, ign); busy = false
            if (err == null) { ctx.toast(tx("Match created. Share the Room ID when you are ready.")); feeText = ""; note = ""; onCreated() } else ctx.toast(err)
        }
    }
    if (confirm) AppDialog(tx("Create this match?"), { confirm = false }, tx("CREATE"), { confirm = false; create() }, tx("CANCEL")) {
        Text("${game.title.ifBlank { game.name }} • ${slotLabel(players)}", fontWeight = FontWeight.Bold)
        Text("${tx("Entry fee")}: ${money(fee)}   ${tx("Winning")}: ${money(prize)}")
        Text(matchDate(startTime))
        Text(tx("Your entry fee is taken now. Once created, a match cannot be cancelled or deleted."), fontSize = 12.sp, color = Color.Gray)
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)) {
        Text(tx("Game"), color = Color.Gray, fontSize = 12.sp)
        // Game tiles (image + name), 3 in a row; the chosen game has an orange border.
        games.chunked(3).forEach { rowGames ->
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                rowGames.forEach { g ->
                    Column(Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(PvpCardC)
                        .border(if (g.id == game.id) 2.dp else 0.dp, Orange, RoundedCornerShape(10.dp)).bounceClick { gameId = g.id; slots = g.slotOptions().first() }) {
                        AsyncImage(g.image.ifBlank { g.bannerUrl() }, null, Modifier.fillMaxWidth().aspectRatio(1.23f), contentScale = ContentScale.Crop)
                        Text(g.name, Modifier.fillMaxWidth().background(LabelC).padding(vertical = 4.dp, horizontal = 2.dp), textAlign = TextAlign.Center, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1, color = onC(LabelC))
                    }
                }
                repeat(3 - rowGames.size) { Spacer(Modifier.weight(1f)) }
            }
        }
        // Live preview: the match card exactly as it will look in the lists (banner, tags, title, time, prize, entry fee).
        PvpCard(
            PvpMatch(gameId = game.id, gameName = game.name, gameImage = game.image, creatorName = user.username, entryFee = fee, prize = prize,
                slots = players.toLong(), startTime = startTime, title = game.title),
            game.bannerUrl(), false, {}, preview = true
        )
        Text(tx("Players"), Modifier.padding(top = 10.dp), color = Color.Gray, fontSize = 12.sp)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { n -> PvpChip(slotLabel(n), n == players) { slots = n } }
        }
        Text("${tx("Entry fee")} (${tx("minimum")} ${money(Pvp.MIN_FEE)})", Modifier.padding(top = 10.dp), color = Color.Gray, fontSize = 12.sp)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pvp.QUICK_FEES.forEach { f -> PvpChip("$f", feeText == "$f") { feeText = "$f" } }
        }
        LineField(feeText, { feeText = it.filter { c -> c.isDigit() }.take(6) }, tx("Entry fee (coins)"), kb = KeyboardType.Number)
        if (feeText.isNotBlank() && !feeOk) Text(tx("Minimum entry fee is") + " " + money(Pvp.MIN_FEE), color = Red, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
        Row(Modifier.fillMaxWidth().padding(top = 14.dp).clip(RoundedCornerShape(10.dp)).background(PencilBlack).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(tx("Winning (automatic)"), color = Color.Gray, fontSize = 12.sp)
                Row(verticalAlignment = Alignment.CenterVertically) { CoinIcon(20); Spacer(Modifier.width(6.dp)); Text(if (feeOk) money(prize) else "-", fontSize = 24.sp, fontWeight = FontWeight.Bold) }
            }
            Column(horizontalAlignment = Alignment.End) { Text(tx("Your wallet"), color = Color.Gray, fontSize = 12.sp); Text(money(user.balance()), fontWeight = FontWeight.Bold) }
        }
        Spacer(Modifier.height(10.dp))
        LineField(ign, { ign = it.take(30) }, tx("Your in-game name"))
        Text(tx("Match time"), Modifier.padding(top = 14.dp), color = Color.Gray, fontSize = 12.sp)
        Row(Modifier.fillMaxWidth().padding(top = 6.dp).clip(RoundedCornerShape(10.dp)).background(PencilBlack).clickable { pickDateTime(ctx, startTime) { startTime = it } }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(matchDate(startTime), Modifier.weight(1f), fontSize = 15.sp)
            Text(tx("CHANGE"), color = Orange, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
        Spacer(Modifier.height(10.dp))
        LineField(note, { note = it.take(300) }, tx("Note / rules (optional)"))
        Spacer(Modifier.height(18.dp))
        Btn(if (busy) tx("PLEASE WAIT...") else tx("CREATE MATCH"), Modifier.fillMaxWidth(), color = if (canPay) Orange else ButtonC, enabled = !busy) {
            if (!feeOk) ctx.toast(tx("Minimum entry fee is") + " " + money(Pvp.MIN_FEE))
            else if (startTime < System.currentTimeMillis() - 60_000) ctx.toast(tx("Choose a match time in the future"))
            else if (ign.isBlank()) ctx.toast(tx("Enter your in-game name"))
            else if (!canPay) ctx.toast(tx("Insufficient balance. Add coins first."))
            else confirm = true
        }
        Text(tx("After creating, enter your Room ID and password inside the match. The match then moves to Ongoing."), Modifier.padding(top = 10.dp), color = Color.Gray, fontSize = 12.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(20.dp))
    }
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
private fun PvpMineTab(nav: NavController) {
    val listN by rflow(init = null as List<PvpMatch>?) { Repo.myPvp() }
    val games by rflow(init = emptyList<PvpGame>()) { Repo.pvpGames() }
    val pager = androidx.compose.foundation.pager.rememberPagerState(initialPage = 0, pageCount = { 3 })
    val scope = rememberCoroutineScope()
    val tabSkel = rememberTapSkeleton(pager.currentPage, showFirst = false)
    val list = listN ?: return Column(Modifier.fillMaxSize()) {
        TabsRow(listOf(tx("ONGOING"), tx("UPCOMING"), tx("RESULTS")), -1) { }
        MatchSkeletonList()
    }
    val keys = listOf("ongoing", "upcoming", "completed")
    Column(Modifier.fillMaxSize()) {
        TabsRow(listOf(tx("ONGOING"), tx("UPCOMING"), tx("RESULTS")), pager.currentPage) { i -> scope.launch { pager.animateScrollToPage(i) } }
        androidx.compose.foundation.pager.HorizontalPager(pager, Modifier.fillMaxSize(), beyondBoundsPageCount = 2) { page ->
            val rows = remember(list, page) { list.filter { val s = statusOf(it); if (keys[page] == "completed") s == "completed" || s == "cancelled" else s == keys[page] } }
            Column(Modifier.fillMaxSize()) {
                if (tabSkel) MatchSkeletonList()
                else if (rows.isEmpty()) EmptyMatches(keys[page])
                else LazyColumn(contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)) {
                    items(rows, key = { it.id }) { m -> PvpCard(m, games.firstOrNull { it.id == m.gameId }?.bannerUrl().orEmpty(), true, { nav.go("pvpmatch/${m.id}") }) }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------------------------
// One match
// ---------------------------------------------------------------------------------------------------------------
@Composable
private fun PvpShotImage(mid: String, uid: String) {
    val bmp by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, mid, uid) {
        value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) {
            try {
                val v = Repo.pvpShot(mid, uid)
                val bytes = android.util.Base64.decode(v.substringAfter("base64,", v), android.util.Base64.DEFAULT)
                android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
            } catch (e: Exception) { null }
        }
    }
    var big by remember { mutableStateOf(false) }
    val b = bmp
    if (b == null) Text(tx("Loading screenshot..."), color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp))
    else {
        Image(b, null, Modifier.fillMaxWidth().heightIn(max = 260.dp).padding(top = 6.dp).clip(RoundedCornerShape(8.dp)).clickable { big = true }, contentScale = ContentScale.Fit)
        if (big) androidx.compose.ui.window.Dialog(onDismissRequest = { big = false }) {
            Image(b, null, Modifier.fillMaxWidth().clickable { big = false }, contentScale = ContentScale.Fit)
        }
    }
}

@Composable
private fun CopyRow(label: String, value: String) {
    val ctx = LocalContext.current
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF0E0120)).padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(label, color = Color.Gray, fontSize = 11.sp); Text(value.ifBlank { "-" }, fontSize = 17.sp, fontWeight = FontWeight.Bold) }
        if (value.isNotBlank()) Text(tx("COPY"), color = Orange, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { copyText(ctx, label, value) }.padding(8.dp))
    }
}

@Composable
fun PvpMatchScreen(nav: NavController, id: String) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val user by rflow(init = User()) { Repo.me() }
    val mN by rflow(id, init = null as PvpMatch?) { Repo.pvpMatch(id) }
    val players by rflow(id, init = emptyList<PvpPlayer>()) { Repo.pvpPlayers(id) }
    val reports by rflow(id, init = emptyList<PvpReport>()) { Repo.pvpReports(id) }
    val allGames by rflow(init = emptyList<PvpGame>()) { Repo.pvpGames() }
    val me = Repo.uid()
    val m = mN ?: return SkeletonPage(tx("Player Match"), nav, tabs = false)
    val iAmIn = players.any { it.uid == me }
    val isCreator = m.creatorUid == me
    val st = statusOf(m)
    val closed = st == "completed" || st == "cancelled"
    val room by rflow(id, iAmIn, init = "" to "") { if (iAmIn) Repo.pvpRoom(id) else kotlinx.coroutines.flow.flowOf("" to "") }
    var roomId by remember(room) { mutableStateOf(room.first) }
    var roomPass by remember(room) { mutableStateOf(room.second) }
    var savingRoom by remember { mutableStateOf(false) }
    var joining by remember { mutableStateOf(false) }
    var myIgn by remember { mutableStateOf("") }
    var editSeat by remember { mutableStateOf<PvpPlayer?>(null) }
    var editIgn by remember { mutableStateOf("") }
    var shot by remember { mutableStateOf<Uri?>(null) }
    var winnerName by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var sending by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u -> if (u != null) shot = u }
    val myReport = reports.firstOrNull { it.uid == me }
    val full = players.size >= m.slots

    editSeat?.let { p ->
        AppDialog(tx("Edit game name"), { editSeat = null }, tx("SAVE"), {
            editSeat = null; val v = editIgn
            scope.launch { val err = Repo.updatePvpIgn(m, p.seat, v); ctx.toast(err ?: tx("Saved")) }
        }, tx("CANCEL"), confirmEnabled = editIgn.isNotBlank()) {
            DialogNameField(editIgn, { editIgn = it.take(30) }, tx("Your in-game name"))
        }
    }
    if (st == "completed") { val gm = allGames.firstOrNull { it.id == m.gameId }; PvpResultPage(nav, m, players, reports, me, gm?.rules.orEmpty(), gm?.bannerUrl().orEmpty()); return }
    Column(Modifier.fillMaxSize()) {
        BackBar(m.label(), nav)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(14.dp)) {
            // ----- summary -----
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(MatchC).slateEdge(RoundedCornerShape(12.dp)).padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AsyncImage(m.gameImage, null, Modifier.size(60.dp).clip(RoundedCornerShape(10.dp)), contentScale = ContentScale.Crop)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("${m.label()}  •  ${slotLabel(m.slots.toInt())}", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("${tx("Created by")} ${m.creatorName}", color = Color.Gray, fontSize = 12.sp)
                        Text(matchDate(m.startTime), color = Color.Gray, fontSize = 12.sp)
                    }
                    StatusTag(m)
                }
                HorizontalDivider(Modifier.padding(vertical = 10.dp), color = Color.Gray.copy(alpha = .4f))
                Row { CoinText(tx("Entry"), m.entryFee, Modifier.weight(1f)); CoinText(tx("Winning"), m.prize, Modifier.weight(1f)); Column(Modifier.weight(1f)) { Text(tx("Players"), color = Color.Gray, fontSize = 11.sp); Text("${players.size}/${m.slots}", fontWeight = FontWeight.Bold, fontSize = 15.sp) } }
                if (m.note.isNotBlank()) Text(m.note, Modifier.padding(top = 10.dp), fontSize = 13.sp)
            }
            val rules = allGames.firstOrNull { it.id == m.gameId }?.rules.orEmpty()
            if (rules.isNotBlank()) {
                Text(tx("RULES"), Modifier.padding(top = 16.dp, bottom = 6.dp), color = Purple, fontWeight = FontWeight.Bold)
                Text(rules, Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(PvpCardC).padding(12.dp), fontSize = 13.sp)
            }
            // ----- players -----
            Text(tx("PLAYERS"), Modifier.padding(top = 16.dp, bottom = 6.dp), color = Purple, fontWeight = FontWeight.Bold)
            players.forEach { p ->
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(8.dp)).background(PvpCardC).padding(horizontal = 12.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(p.username + if (p.uid == me) "  (${tx("You")})" else "", fontSize = 14.sp)
                        if (p.ign.isNotBlank()) Text("${tx("Game name")}: ${p.ign}", fontSize = 12.sp, color = Color.LightGray)
                    }
                    if (p.uid == me && !closed) Text(tx("EDIT"), color = Orange, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { editIgn = p.ign; editSeat = p }.padding(end = 10.dp))
                    if (p.ign.isNotBlank() && p.uid != me) Text(tx("COPY"), color = Orange, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { copyText(ctx, tx("Game name"), p.ign) }.padding(end = 10.dp))
                    if (p.uid == m.creatorUid) Text(tx("CREATOR"), color = Orange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
            // ----- join -----
            if (!iAmIn && !closed && !full) {
                Spacer(Modifier.height(12.dp))
                LineField(myIgn, { myIgn = it.take(30) }, tx("Your in-game name"))
                Spacer(Modifier.height(8.dp))
                Btn(if (joining) tx("PLEASE WAIT...") else "${tx("JOIN")}  (${money(m.entryFee)})", Modifier.fillMaxWidth(), color = Orange, enabled = !joining) {
                    if (myIgn.isBlank()) { ctx.toast(tx("Enter your in-game name")); return@Btn }
                    joining = true
                    scope.launch { val err = Repo.joinPvp(m, user.username, myIgn); joining = false; if (err == null) ctx.toast(tx("Joined!")) else ctx.toast(err) }
                }
            }
            if (!iAmIn && (closed || full)) Text(tx("This match is closed for new players."), Modifier.padding(top = 12.dp), color = Color.Gray, fontSize = 13.sp)
            // ----- room -----
            if (iAmIn && st != "cancelled") {
                Text(tx("ROOM ID & PASSWORD"), Modifier.padding(top = 18.dp, bottom = 6.dp), color = Purple, fontWeight = FontWeight.Bold)
                if (room.first.isNotBlank() || room.second.isNotBlank()) {
                    CopyRow(tx("Room ID"), room.first); CopyRow(tx("Password"), room.second)
                    if (!isCreator && !closed) Text(tx("Copy them, open the game and join the room."), color = Color.Gray, fontSize = 12.sp)
                } else if (!isCreator) Text(tx("Waiting for the creator to share the Room ID."), color = Color.Gray, fontSize = 13.sp)
                if (isCreator && !closed) {
                    Column(Modifier.fillMaxWidth().padding(top = 8.dp).clip(RoundedCornerShape(10.dp)).background(PvpCardC).padding(12.dp)) {
                        Text(if (room.first.isBlank()) tx("Create the room in the game, then enter its ID and password here. The match will move to Ongoing.") else tx("Only you can change the Room ID and password."), fontSize = 12.sp, color = Color.Gray)
                        LineField(roomId, { roomId = it.take(60) }, tx("Room ID"))
                        LineField(roomPass, { roomPass = it.take(60) }, tx("Password"))
                        Spacer(Modifier.height(10.dp))
                        Btn(if (savingRoom) tx("PLEASE WAIT...") else if (room.first.isBlank()) tx("SAVE ROOM & START") else tx("UPDATE ROOM"), Modifier.fillMaxWidth(), color = Orange, enabled = !savingRoom) {
                            savingRoom = true
                            scope.launch { val err = Repo.savePvpRoom(m, roomId, roomPass); savingRoom = false; ctx.toast(err ?: tx("Room saved")) }
                        }
                    }
                }
            }
            // ----- result -----
            if (st == "cancelled") Text(tx("This match was cancelled by the admin. Your entry fee was refunded to your wallet."), Modifier.padding(top = 16.dp), color = Red, fontSize = 13.sp)
            if (m.resultDeclared) {
                Column(Modifier.fillMaxWidth().padding(top = 18.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF0B3D2A)).padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(tx("WINNER"), color = Color(0xFF7CFFB5), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text(m.winnerName.ifBlank { "-" }, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Row(verticalAlignment = Alignment.CenterVertically) { CoinIcon(16); Spacer(Modifier.width(4.dp)); Text(money(m.prize), fontWeight = FontWeight.Bold) }
                }
            }
            if (iAmIn && st != "cancelled") {
                Text(tx("MATCH RESULT"), Modifier.padding(top = 18.dp, bottom = 6.dp), color = Purple, fontWeight = FontWeight.Bold)
                reports.forEach { r ->
                    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(10.dp)).background(PvpCardC).padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(r.username + if (r.uid == me) "  (${tx("You")})" else "", Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                            Text(if (m.resultDeclared) tx("DONE") else tx("PENDING"), color = if (m.resultDeclared) SuccessC else Orange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        if (r.winnerName.isNotBlank()) Text("${tx("Winner")}: ${r.winnerName}", fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                        if (r.note.isNotBlank()) Text(r.note, fontSize = 13.sp, color = Color.LightGray, modifier = Modifier.padding(top = 2.dp))
                        PvpShotImage(m.id, r.uid)
                    }
                }
                if (!closed && myReport == null) {
                    if (st != "ongoing" && m.startTime > System.currentTimeMillis()) Text(tx("You can send the match screenshot once the creator has shared the Room ID and the match is Ongoing."), color = Color.Gray, fontSize = 12.sp)
                    else Column(Modifier.fillMaxWidth().padding(top = 6.dp).clip(RoundedCornerShape(10.dp)).background(PvpCardC).padding(12.dp)) {
                        Text(tx("After the match, send your result screenshot. The admin checks it and pays the winner."), fontSize = 12.sp, color = Color.Gray)
                        shot?.let { AsyncImage(it, null, Modifier.fillMaxWidth().heightIn(max = 240.dp).padding(top = 8.dp).clip(RoundedCornerShape(8.dp)), contentScale = ContentScale.Fit) }
                        Spacer(Modifier.height(8.dp))
                        Btn(if (shot == null) tx("ATTACH SCREENSHOT") else tx("CHANGE SCREENSHOT"), Modifier.fillMaxWidth()) { picker.launch("image/*") }
                        LineField(note, { note = it.take(500) }, tx("Write something for the admin (optional)"))
                        LineField(winnerName, { winnerName = it.take(40) }, tx("Winner name (optional)"))
                        Spacer(Modifier.height(10.dp))
                        Btn(if (sending) tx("PLEASE WAIT...") else tx("SEND TO ADMIN"), Modifier.fillMaxWidth(), color = if (shot != null) Orange else ButtonC, enabled = !sending) {
                            val s = shot
                            if (s == null) ctx.toast(tx("Attach the match screenshot"))
                            else { sending = true; scope.launch {
                                val data = ProofImage.toDataUri(ctx, s)
                                if (data == null) { sending = false; ctx.toast(tx("Could not read the screenshot. Choose another image.")) }
                                else {
                                    val err = Repo.submitPvpReport(m, user.username, data, winnerName, note); sending = false
                                    if (err == null) { ctx.toast(tx("Sent. The admin will review it.")); shot = null } else ctx.toast(err)
                                }
                            } }
                        }
                    }
                }
                if (!closed && myReport != null) Text(tx("Your screenshot is sent. Waiting for the admin to review."), Modifier.padding(top = 6.dp), color = Orange, fontSize = 13.sp)
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

// ---------------------------------------------------------------------------------------------------------------
// Finished match: same look as the full-map Match Result page (image, title, details, WINNER table, Match Result table)
// ---------------------------------------------------------------------------------------------------------------
@Composable
private fun PvpResultTable(title: String, rows: List<PvpPlayer>, winnerUid: String, prize: Double, decimals: Boolean) {
    val dark = ResultHeadBg; val ink = Color(0xFF222222)
    Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp).padding(top = 18.dp).clip(RoundedCornerShape(4.dp))) {
        Text(title, Modifier.fillMaxWidth().background(ResultTitleBg).padding(vertical = 11.dp), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.White)
        Row(Modifier.fillMaxWidth().background(dark).padding(vertical = 10.dp, horizontal = 4.dp)) {
            listOf("#" to 0.6f, tx("Player Name") to 2.2f, tx("Result") to 1f, tx("Winning") to 1.3f).forEach { (t, w) ->
                Text(t, Modifier.weight(w), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White, maxLines = 1)
            }
        }
        rows.forEachIndexed { i, p ->
            val won = p.uid == winnerUid
            Row(Modifier.fillMaxWidth().background(Color.White).padding(vertical = 9.dp, horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${i + 1}", Modifier.weight(0.6f), textAlign = TextAlign.Center, color = ink, fontSize = 14.sp)
                Text(p.ign.ifBlank { p.username }, Modifier.weight(2.2f), textAlign = TextAlign.Center, color = ink, fontSize = 14.sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                Text(if (won) tx("WON") else tx("LOST"), Modifier.weight(1f), textAlign = TextAlign.Center, color = if (won) Color(0xFF1B8A4B) else Color(0xFFE01B10), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                val amt = if (won) prize else 0.0
                Text(if (decimals) fmt(amt) else money(amt), Modifier.weight(1.3f), textAlign = TextAlign.Center, color = ink, fontSize = 14.sp)
            }
            if (i < rows.lastIndex) HorizontalDivider(color = Color(0xFFDDDDDD))
        }
    }
}

@Composable
private fun PvpResultPage(nav: NavController, m: PvpMatch, players: List<PvpPlayer>, reports: List<PvpReport>, me: String, rules: String, banner: String = "") {
    val ranked = players.sortedByDescending { it.uid == m.winnerUid }
    val iAmIn = players.any { it.uid == me }
    Column(Modifier.fillMaxSize()) {
        BackBar(tx("Match Result"), nav)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 28.dp)) {
            FullImage(banner.ifBlank { m.gameImage }, Modifier.fillMaxWidth().padding(14.dp), 6)
            Text(m.label(), Modifier.padding(horizontal = 14.dp), color = Orange, fontSize = 17.sp, fontWeight = FontWeight.Medium)
            Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.raised().background(Color.White).padding(horizontal = 10.dp, vertical = 7.dp)) {
                    Text("${tx("Organised on")} ", color = Color.Black, fontSize = 13.sp)
                    Text(matchDate(m.startTime).lowercase(), color = Color.Black, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { CoinChip("Winning Prize", money(m.prize)); CoinChip("Entry Fee", money(m.entryFee)) }
                Text("${tx("Organised by")} ${m.creatorName}  •  ${slotLabel(m.slots.toInt())}", color = Color.Gray, fontSize = 12.sp)
            }
            if (rules.isNotBlank()) Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp).padding(top = 8.dp)) {
                Text(tx("Rules"), color = Color(0xFF4FD1A5), fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                Text(rules.trim(), Modifier.padding(top = 4.dp), color = Color(0xFF8E8EA0), fontSize = 16.sp, lineHeight = 22.sp)
            }
            PvpResultTable(tx("Winner"), ranked.take(1), m.winnerUid, m.prize, true)
            PvpResultTable(tx("Match Result"), ranked, m.winnerUid, m.prize, false)
            if (iAmIn && reports.isNotEmpty()) {
                Text(tx("SCREENSHOTS"), Modifier.padding(start = 14.dp, end = 14.dp, top = 22.dp, bottom = 6.dp), color = Purple, fontWeight = FontWeight.Bold)
                reports.forEach { r ->
                    Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp).clip(RoundedCornerShape(10.dp)).background(PvpCardC).padding(12.dp)) {
                        Text(r.username + if (r.uid == me) "  (${tx("You")})" else "", fontWeight = FontWeight.SemiBold)
                        if (r.winnerName.isNotBlank()) Text("${tx("Winner")}: ${r.winnerName}", fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                        if (r.note.isNotBlank()) Text(r.note, fontSize = 13.sp, color = Color.LightGray)
                        PvpShotImage(m.id, r.uid)
                    }
                }
            }
        }
    }
}


/** Text field for the WHITE AppDialog: dark text + dark cursor (default theme text is white = invisible). */
@Composable
private fun DialogNameField(v: String, onV: (String) -> Unit, label: String, modifier: Modifier = Modifier) {
    OutlinedTextField(v, onV, modifier.fillMaxWidth(), singleLine = true, label = { Text(label) },
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = Color.Black, unfocusedTextColor = Color.Black, cursorColor = Color.Black,
            focusedBorderColor = Color.Black, unfocusedBorderColor = Color.DarkGray,
            focusedLabelColor = Color.Black, unfocusedLabelColor = Color.DarkGray))
}
