package com.bestwinesport.app

/**
 * Address of your Railway backend (see backend/README.md). No secret goes here - the Telegram bot token
 * lives only in Railway variables. Images are saved in Firebase as "tgimg:<imageId>" and shown through
 * BASE_URL/api/images/<imageId>.
 */
object BackendConfig {
    const val BASE_URL = "https://bestwin-backend-production.up.railway.app"

    /** Set from Admin -> Settings -> "Backend server address". Empty = the built-in address above. */
    @Volatile var customUrl: String = ""

    // The address is fixed: any "backendUrl" value in Firebase settings is ignored.
    fun base(): String = BASE_URL.trimEnd('/')

    fun resolve(v: String): String =
        if (v.startsWith("tgimg:")) base() + "/api/images/" + v.removePrefix("tgimg:") else v
}
