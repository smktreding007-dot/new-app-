package com.bestwinesport.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

data class AppLanguageOption(val code: String, val label: String, val nativeName: String)

/** Lightweight persisted UI localization for the app's shared navigation and support surfaces. */
object AppLanguage {
    val options = listOf(
        AppLanguageOption("en", "English", "English"),
        AppLanguageOption("hi", "Hindi", "हिन्दी")

    )

    var current by mutableStateOf("en")
        private set

    private val english = mapOf(
        "choose_language" to "Choose language", "continue" to "CONTINUE",
        "tab_earn" to "Earn", "tab_play" to "Play", "tab_rank" to "Rank", "tab_home" to "Home", "tab_wallet" to "Wallet", "tab_account" to "Account",
        "change_language" to "Change language", "push_notifications" to "Push notifications", "music" to "Music", "my_profile" to "My profile",
        "my_wallet" to "My wallet", "my_matches" to "My matches", "store" to "Store", "my_orders" to "My orders",
        "statistics" to "My statistics", "rewards" to "My rewards", "referrals" to "My referrals", "announcements" to "Announcements",
        "tutorial" to "App tutorial", "about" to "About us", "customer_support" to "Customer support", "share_app" to "Share app",
        "terms" to "Terms & conditions", "logout" to "Log out", "matches_played" to "Matches played", "total_kills" to "Total kills",
        "amount_won" to "Amount won", "kyc_verified" to "KYC verified", "kyc_pending" to "KYC pending",
        "support_channels" to "Contact support", "address" to "Address", "email" to "Email", "whatsapp" to "WhatsApp",
        "instagram" to "Instagram", "telegram" to "Telegram", "phone" to "Phone", "street" to "Street", "hours" to "Hours",
        "support_empty" to "Support details will be added soon.", "developer" to "Developer", "developer_team_default" to "DOUx24 Development Team",
        "developer_info_default" to "For app feedback, bugs, or technical questions.", "contact_developer" to "Contact developer",
        "contact_not_configured" to "Developer contact is not configured yet.",
        "faq" to "FAQs", "create_ticket" to "Create support ticket", "my_tickets" to "My tickets", "new_ticket" to "New support ticket",
        "ticket_subject" to "Subject", "ticket_category" to "Category", "describe_issue" to "Describe your issue", "send_ticket" to "Submit ticket",
        "send_reply" to "Send reply", "status" to "Status", "ticket_id" to "Ticket ID", "no_tickets" to "No tickets yet",
        "search_faq" to "Search FAQs", "last_updated" to "Last updated", "ticket_closed" to "This ticket is closed"
    )

    private val translations: Map<String, Map<String, String>> = mapOf(
        "en" to english,
        "hi" to mapOf(
            "choose_language" to "भाषा चुनें", "continue" to "आगे बढ़ें", "tab_earn" to "कमाएँ", "tab_play" to "खेलें", "tab_rank" to "रैंकिंग", "tab_home" to "होम", "tab_wallet" to "वॉलेट", "tab_account" to "खाता",
            "change_language" to "भाषा बदलें", "push_notifications" to "पुश नोटिफ़िकेशन", "music" to "संगीत", "my_profile" to "मेरी प्रोफ़ाइल", "my_wallet" to "मेरा वॉलेट", "my_matches" to "मेरे मैच", "store" to "स्टोर", "my_orders" to "मेरे ऑर्डर",
            "statistics" to "मेरे आँकड़े", "rewards" to "मेरे इनाम", "referrals" to "मेरे रेफ़रल", "announcements" to "घोषणाएँ", "tutorial" to "ऐप ट्यूटोरियल", "about" to "हमारे बारे में", "customer_support" to "ग्राहक सहायता", "share_app" to "ऐप शेयर करें", "terms" to "नियम और शर्तें", "logout" to "लॉग आउट",
            "matches_played" to "खेले गए मैच", "total_kills" to "कुल किल", "amount_won" to "जीती गई राशि", "kyc_verified" to "KYC सत्यापित", "kyc_pending" to "KYC लंबित", "support_channels" to "सहायता से संपर्क करें", "address" to "पता", "email" to "ईमेल", "whatsapp" to "WhatsApp", "instagram" to "Instagram", "telegram" to "Telegram", "phone" to "फ़ोन", "street" to "सड़क", "hours" to "समय",
            "support_empty" to "सहायता की जानकारी जल्द जोड़ी जाएगी।", "developer" to "डेवलपर", "developer_team_default" to "DOUx24 विकास टीम", "developer_info_default" to "ऐप सुझाव, बग या तकनीकी प्रश्नों के लिए संपर्क करें।", "contact_developer" to "डेवलपर से संपर्क करें", "contact_not_configured" to "डेवलपर संपर्क अभी सेट नहीं किया गया है।",
            "faq" to "अक्सर पूछे जाने वाले सवाल", "create_ticket" to "सहायता टिकट बनाएँ", "my_tickets" to "मेरे टिकट", "new_ticket" to "नया सहायता टिकट", "ticket_subject" to "विषय", "ticket_category" to "श्रेणी", "describe_issue" to "अपनी समस्या बताएँ", "send_ticket" to "टिकट भेजें", "send_reply" to "जवाब भेजें", "status" to "स्थिति", "ticket_id" to "टिकट आईडी", "no_tickets" to "अभी कोई टिकट नहीं", "search_faq" to "FAQ खोजें", "last_updated" to "अंतिम अपडेट", "ticket_closed" to "यह टिकट बंद है"
        ),
    )

    fun load(context: Context) {
        val saved = context.getSharedPreferences("clash2_preferences", Context.MODE_PRIVATE).getString("language", "en") ?: "en"
        current = options.firstOrNull { it.code == saved }?.code ?: "en"
    }

    fun select(context: Context, languageCode: String) {
        if (options.none { it.code == languageCode }) return
        current = languageCode
        context.getSharedPreferences("clash2_preferences", Context.MODE_PRIVATE).edit().putString("language", languageCode).apply()
    }

    fun text(key: String): String = translations[current]?.get(key) ?: english[key] ?: key
    val isRtl: Boolean get() = false
}

fun tr(key: String): String = AppLanguage.text(key)

fun brandAppName(text: String): String = Regex("(?i)\\bclash\\s*(?:2(?:\\.0)?|admin)\\b").replace(text, "DOUx24")

/** Translates a hard-coded English UI string into the selected language (Hindi), falls back to the English text. */
fun tx(text: String): String = if (AppLanguage.current == "hi") HiExtra[text] ?: text else text
