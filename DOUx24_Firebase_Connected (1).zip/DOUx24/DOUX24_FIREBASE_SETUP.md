# DOUx24 Firebase setup

- Firebase project: `doux24-c9bb3`
- Realtime Database URL: `https://doux24-c9bb3-default-rtdb.firebaseio.com`
- Android application IDs:
  - Player (`app/`): `com.doux24.player`
  - Admin (`admin/`): `com.doux24.admin`
  - Staff (`staff/`): `com.doux24.staff`
- Each module contains the DOUx24 `google-services.json` with all three registered Android clients.
- `.firebaserc` now targets `doux24-c9bb3`.
- Existing Kotlin namespaces and source package paths are intentionally retained to avoid a risky broad package refactor.
- Firebase Storage is not required for the current no-user-image-upload scope.

## Important before production
The copied app/backend source still contains the original BESTWIN Railway backend URL and related payment/backend integration settings. This archive does not deploy a separate DOUx24 backend or change those remote services. Configure and deploy a separate DOUx24 backend before using payment, backend-mediated notifications, or other backend endpoints in production, so the DOUx24 app does not share BESTWIN's backend.
